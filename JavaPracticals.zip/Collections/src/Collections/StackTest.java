package Collections;
import java.util.*;

public class StackTest {
	public static void printStack(Collection<Number>stack) {
		if(stack.isEmpty()) {
			System.out.println("the stack is empty");
		}else {
			System.out.printf("stack contains: %s (top)\n", stack);
		}
	}
	
    public static void main(String[]args) {
	   Stack<Number> stack = new Stack<Number>();
	   stack.push(12L);
	   System.out.println("Stack pushed 12L");
	   stack.push(34567);
	   System.out.println("Stack pushed 34567");
	   stack.push(1.0F);
	   System.out.println("Stack pushed 1.0F");
	   stack.push(1234.5678);
	   System.out.println("Stack pushed 1234.5678");
	   printStack(stack);
	   
	   try {
		   Number removedObject = null;
		   while(true) {
			   removedObject = stack.pop();
			   System.out.printf("\nPopped %s\n", removedObject);
			   printStack(stack);
		   }
	   }catch(EmptyStackException emptyStackException) {
		   emptyStackException.printStackTrace();
	   }
    }
}
