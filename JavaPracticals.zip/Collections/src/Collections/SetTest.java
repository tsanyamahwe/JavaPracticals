package Collections;
import java.util.*;

public class SetTest {
	private static void printNonDuplicates(Collection<String> value) {
		Set<String> set = new HashSet<String>(value);
		System.out.print("\nNon-Duplicate-List:");
		for(String list: set) {
			System.out.printf("%s ", list);
		}
	}
   public static void main(String[]args) {
	   String[] colors = {"red", "white", "blue", "yellow", "green", "grey", "orange", "tan", "white", "yellow", "peach", "grey", "orange"};
	   List<String> list = Arrays.asList(colors);
	   
	   System.out.printf("List: %s\n", list);
	  // printNonDuplicates(list);
	   //Set<String> set = new HashSet<String>(list);
	   System.out.printf("\nNon Duplicates are: %s ", new HashSet<String>(list));
   }
}
