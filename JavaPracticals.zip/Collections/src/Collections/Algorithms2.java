package Collections;
import java.util.*;

public class Algorithms2 {
   public static void main(String[]args) {
	   String[]colors = {"red", "white", "yellow", "blue"};
	   List<String> list = Arrays.asList(colors);
	   List<String> list2 = new ArrayList<String>();
	   
	   list2.add("black");
	   list2.add("red");
	   list2.add("green");
	   
	   System.out.print("Before AddAll, list2 contains: ");
	   for(String string: list2) {
		   System.out.printf("%s ", string);
	   }
	   Collections.addAll(list2, colors);
	   
	   System.out.print("\nAfter AddAll, list2 contains: ");
	   for(String string: list2) {
		   System.out.printf("%s ", string);
	   }
	   
	   int frequency = Collections.frequency(list2, "red");
	   System.out.printf("\nFrequency of \"red\" in list2 is %d\n", frequency);
	   
	   boolean commonElements = Collections.disjoint(list, list2);
	   System.out.printf("list and list2 %s elements in common\n", (commonElements? "do not have" : "have"));
   }
}
