package Collections;
import java.io.*;
import java.util.*;

public class PropertiesTable {
	private static void listProperties(Properties prop) {
		Set<Object> keys = prop.keySet();
		for(Object key: keys) {
			System.out.printf("%s\t%s\n", key, prop.getProperty((String)key));
		}
		System.out.println();
	}
	
	private static void saveProperties(Properties prop) {
		try {
			FileOutputStream output = new FileOutputStream("prop.txt");
			prop.store(output, "Sample Properties");
			output.close();
			System.out.println("After saving properties");
			listProperties(prop);
		}catch(IOException ioException) {
			ioException.printStackTrace();
		}
	}
	
	private static void loadProperties(Properties prop) {
		try {
			FileInputStream input = new FileInputStream("prop.txt");
			prop.load(input);
			input.close();
			System.out.println("After loading properties");
			listProperties(prop);
		}catch(IOException ioException) {
			ioException.printStackTrace();
		}
	}
	public static void main(String[]args) {
		Properties table = new Properties();
		table.setProperty("color", "blue");
		table.setProperty("width", "200");
		
		System.out.println("After setting properties");
		listProperties(table);
		
		table.setProperty("color", "red");
		
		System.out.println("After replacing properties");
		listProperties(table);
		
		saveProperties(table);
		
		table.clear();
		System.out.println("After clearing properties");
		listProperties(table);
		
		loadProperties(table);
	}
}
