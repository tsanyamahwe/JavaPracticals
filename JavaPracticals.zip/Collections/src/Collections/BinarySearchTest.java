package Collections;
import java.util.*;
import java.util.Arrays;

public class BinarySearchTest {
   public static void printSearchResults(List<String> list, String key) {
		int result = 0;
		
		System.out.printf("\nSearching for: %s\n", key);
		result = Collections.binarySearch(list, key);
		
		if(result >= 0) {
			System.out.printf("Found at index: %d\n", result);
		}else {
			System.out.printf("Not found: (%d)\n", result);
		}
   }
	
   public static void main(String[]args) {
	   String[] colors = {"green", "yellow", "blue", "black", "purple", "orange", "grey", "white"};
	   List<String> list = new ArrayList<String>(Arrays.asList(colors));
	   
	   Collections.sort(list);
	   System.out.printf("Sorted ArrayList: %s\n", list);
	   
	   printSearchResults(list, colors[3]);
	   printSearchResults(list, colors[0]);
	   printSearchResults(list, colors[7]);
	   printSearchResults(list, "pink");
	   printSearchResults(list, "aqua");
	   printSearchResults(list, "purle");
   }
}
