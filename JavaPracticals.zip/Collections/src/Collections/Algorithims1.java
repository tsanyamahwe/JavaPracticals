package Collections;
import java.util.*;

public class Algorithims1 {
   public static void output(List<Character>listRef) {
	   System.out.print("The list is: ");
	   for(Character ch: listRef) {
		   System.out.printf("%s ", ch);
	   }
	   System.out.printf("\nMax: %s  ", Collections.max(listRef));
	   System.out.printf("Min: %s", Collections.min(listRef));
   }
   
   public static void main(String[] args) {
	   Character[] letters = {'P', 'C', 'M'};
	   List<Character> list = Arrays.asList(letters);
	   System.out.println("List contains:");
	   output(list);
	   
	   System.out.println();
	   Collections.reverse(list);
	   System.out.println("\nAfter calling reverse, it contains:");
	   output(list);
	   
	   System.out.println();
	   Character[] lettersCopy = new Character[3];
	   List<Character> copyList = Arrays.asList(lettersCopy);
	   Collections.copy(copyList, list);
	   System.out.println("\nAfter copying, copyList contains:");
	   output(copyList);
	   
	   System.out.println();
	   Collections.fill(list, 'R');
	   System.out.println("\nAfter calling fill, list contains");
	   output(list);
   }
}
