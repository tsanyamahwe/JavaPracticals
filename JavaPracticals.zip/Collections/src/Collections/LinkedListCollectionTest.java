package Collections;
import java.util.*;

public class LinkedListCollectionTest {
	private static void printList(List<String>list) {
		System.out.println("\nList: ");
		for(String color: list) {
			System.out.printf("%s ", color);
		}
		System.out.println();
	}
	
	private static void convertToUppercaseStrings(List<String>list) {
		ListIterator<String>iterator = list.listIterator();
		while(iterator.hasNext()) {
			String color = iterator.next();
			iterator.set(color.toUpperCase());
		}
	}
	
	private static void removeItems(List<String>list, int start, int end) {
		list.subList(start, end).clear(); 
	}
	
	private static void printReverseList(List<String>list) {
		ListIterator<String>iterator = list.listIterator(list.size());
		System.out.println("\nReversed list:");
		while(iterator.hasPrevious()) {
			System.out.printf("%s ", iterator.previous());
		}
	}
	
    public static void main(String[]args) {
    	String[]colors = {"black", "yellow", "green", "blue", "violet", "silver"};
    	List<String>list1 = new LinkedList<String>();
    	
    	for(String color: colors) {
    		list1.add(color);
    	}
    	
    	String[]colors2 = {"gold", "white", "brown", "blue", "grey", "silver"};
    	List<String>list2 = new LinkedList<String>();
    	
    	for(String color: colors2) {
    		list2.add(color);
    	}
    	
    	list1.addAll(list2);
    	list2 = null;
    	printList(list1 );
    	
    	convertToUppercaseStrings(list1);
    	printList(list1 );
    	
    	System.out.println("\n\nDeleting elements from 4 - 6");
    	removeItems(list1, 4,7);
    	printList(list1 );
    	printReverseList(list1 );
    }
}
