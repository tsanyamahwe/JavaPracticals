package Collections;
import java.util.*;

public class QueueTest {
   public static void main(String[]args) {
	   PriorityQueue<Double> queue = new PriorityQueue<Double>();
	   queue.offer(6.7);
	   queue.offer(1.5);
	   queue.offer(2.9);
	   queue.offer(5.3);
	   queue.offer(4.5);
	   queue.offer(7.4);
	   queue.offer(9.5);
	   queue.offer(0.7);
	   
	   System.out.print("Polling from the queue: ");
	   while(queue.size() > 0) {
		   System.out.printf("%.1f ", queue.peek());
		   queue.poll();
	   }
   }
}
