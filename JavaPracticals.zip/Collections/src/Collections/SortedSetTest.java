package Collections;
import java.util.*;

public class SortedSetTest {
	public static void printSet(Collection<String> set) {
		for(String string: set) {
			System.out.printf("%s ", string);
		}
		System.out.println();
	}
	public static void main(String[]args) {
		String[] colors = {"red", "white", "blue", "yellow", "green", "grey", "orange", "tan", "white", "yellow", "peach", "grey", "orange"};
		SortedSet<String> tree = new TreeSet<String>(Arrays.asList(colors));
		System.out.print("Sorted set: ");
		printSet(tree);
		
		System.out.print("\nheadSet (\"Orange\"): ");
		printSet(tree.headSet("orange"));
		
		System.out.print("\ntailSet (\"Orange\"): ");
		printSet(tree.tailSet("orange"));
		
		System.out.printf("\nfirst: %s\n", tree.first());
		System.out.printf("Last: %s\n", tree.last());
	}
}
