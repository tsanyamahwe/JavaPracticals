package Collections;
import java.util.*;

public class WordTypeCount {
	private static void createMap(Map<String, Integer>myMap) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a String: ");
		String input = scanner.nextLine();
		
		String[]tokens = input.split(" ");
		
		for(String token: tokens) {
			String word = token.toLowerCase();
			if(myMap.containsKey(word)) {
				int count = myMap.get(word);
				myMap.put(word, count + 1);
			}else {
				myMap.put(word, 1);
			}
		}
	}
	
	private static void displayMap(Map<String, Integer>myMap) {
		Set<String> set = myMap.keySet();
		Set<String> sortedSet = new TreeSet<String>(set);
		System.out.println("\nMap contains: \nKey\t\tValue");
		for(String sort: sortedSet) {
			System.out.printf("%-10s%10s\n", sort, myMap.get(sort));
		}
		System.out.printf("\nsize: %d\nisEmpty: %b\n", myMap.size(), myMap.isEmpty());
	}
	
	public static void main(String[]args) {
		Map <String, Integer> map = new HashMap<String, Integer>();
		createMap(map);
		displayMap(map);
	}
}
