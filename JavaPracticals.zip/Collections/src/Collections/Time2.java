package Collections;

public class Time2 {
     private int hour;
     private int minute;
     private int second;
     
     public Time2(){
       this(0,0,0);
     }
     
     public Time2(int hr) {
    	 this(hr,0,0);
     }
     
     public Time2(int hr, int min) {
    	 this(hr, min, 0);
     }
     
     public Time2(int hr, int min, int sec) {
    	 setTime(hr, min, sec);
     }
     
     public Time2(Time2 time) {
    	 this(time.getHour(), time.getMinute(), time.getSecond());
     }
     
     public void setTime(int hr, int min, int sec) {
    	 setHour(hr); setMinute(min); setSecond(sec);
     }
     
     public void setHour(int hr) {
    	 if(hr >= 0 && hr < 24) {
    		 hour = hr;
    	 }else {
    		 throw new IllegalArgumentException("An hour should be between 0 - 23 inclusive"); 
    	 }
     }
     
     public void setMinute(int min) {
    	 if(min >= 0 && min < 60) {
    		 minute = min;
    	 }else {
    		 throw new IllegalArgumentException("A minute should be between 0 = 59 inclusive");
    	 }
     }
     
     public void setSecond(int sec) {
    	 if(sec >= 0 && sec < 60) {
    		 second = sec;
    	 }else {
    		 throw new IllegalArgumentException("A second should be between 0 - 59 inclusive");
    	 }
     }
     
     public int getHour() {return hour;}
     
     public int getMinute() {return minute;}
     
     public int getSecond() {return second;}
     
     public String toUniversalString() {
    	 return String.format("%02d:%02d:%02d", getHour(), getMinute(), getSecond());
     }
     
     public String toString() {
    	 return String.format("%d:%02d:%02d %s", ((getHour() == 0 || getHour() == 12)? 12: getHour() % 12), getMinute(), getSecond(), (getHour() < 12? "AM" : "PM"));
     }
}
