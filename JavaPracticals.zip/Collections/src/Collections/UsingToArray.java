package Collections;
import java.util.*;

public class UsingToArray {
   public static void main(String[]args) {
	   String[]colors = {"black", "blue", "yellow"};
	   LinkedList<String>list = new LinkedList<String>(Arrays.asList(colors));
	   
	   list.addLast("red");
	   list.add("pink");
	   list.add(3, "green");
	   list.addFirst("cyan");
	   
	   colors = list.toArray(new String[list.size()]);
	   
	   System.out.println("Colors: ");
	   for(String color: colors) {
		   System.out.printf("%s \n", color);
	   }
	   
	   String[]suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
	   List<String>list1 = new LinkedList<String>(Arrays.asList(suits));
	   
	   System.out.println();
	   System.out.printf("Unsorted array elements are: %s\n", list1);
	   
	   Collections.sort(list1);
	   System.out.printf("Sorted array elements are: %s\n", list1);
	   Collections.sort(list1.reversed());
	   System.out.printf("Reversed sorted array elements are: %s\n", list1);
   }
}
