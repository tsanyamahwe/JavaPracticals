package Recussive;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class SelectionSort {
     private int[]data;
     private static final Random generator = new Random();
      
     public SelectionSort(int size) {
    	 data = new int[size];
    	 for(int i = 0; i < size; i++) {
    		 data[i] = 10 + generator.nextInt(90);
    	 }
     }
     
     public void sort() {
    	 int smallest;
    	 for(int i = 0; i < data.length - 1; i++) {
    		 smallest = i;
    		 for(int index = i + 1; index < data.length; index++) {
    			 if(data[index] < data[smallest]) {
    				 smallest = index;
    			 }
    		 }
    		 swap(i, smallest);
    	 }
     }
     
     public void swap(int first, int second) {
    	 int temporary = data[first];
    	 data[first] = data[second];
    	 data[second] = temporary;
     }
     
     public String toString() {
    	 return Arrays.toString(data);
     }
     
     public static void main(String[]args) {
    	 Scanner scanner = new Scanner(System.in);
    	 
    	 System.out.print("Enter the number of itegers in an Array: ");
    	 int number = scanner.nextInt();
    	
    	 SelectionSort sortArray = new SelectionSort(number);
    	 
    	 System.out.println("Unsorted array: ");
    	 System.out.println(sortArray + "\n");
    	 
    	 sortArray.sort();
    	 
    	 System.out.println("Sorted array: ");
    	 System.out.println(sortArray + "\n");
     }
}
