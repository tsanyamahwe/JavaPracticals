package Recussive;
import java.math.*;

public class FactorialAndFibbonanci {
   
	private static BigInteger factorial(BigInteger number) {
	   if(number.compareTo(BigInteger.ONE) <= 0) {
		   return BigInteger.ONE;
	   }else {
		   return number.multiply(factorial(number.subtract(BigInteger.ONE)));
	   }
   }
   
   private static BigInteger fibbonanci(BigInteger number) {
	   if(number.equals(BigInteger.ZERO)  || number.equals(BigInteger.ONE)) {
		   return number;
	   }else
		   return fibbonanci(number.subtract(BigInteger.ONE)).add(fibbonanci(number.subtract(BigInteger.TWO)));
   } 
   public static void main(String[]args) {
	   
	   for (int count = 0; count <= 50; count++) {
	        System.out.printf("%d! = %d\n", count, factorial(BigInteger.valueOf(count)));
        }
	   
	   for(int counter = 0; counter <= 50; counter++) {
		 System.out.printf("Fibbonanci of %d = %d\n", counter, fibbonanci(BigInteger.valueOf(counter)));   
	   }  
   }
}
