package Recussive;
import java.util.*;

public class LinearArraySearch {
     private int[]data;
     private static final Random generator = new Random();
     
     public LinearArraySearch(int size) {
    	 data = new int[size];
    	 for(int i = 0; i < size; i++) {
    		 data[i] = 10 + generator.nextInt(90);
    	 }
     }
     
     public int linearSearch(int keySearch) {
    	 for(int index = 0; index < data.length; index++) {
    		 if(data[index] == keySearch) {
    			 return index;
    		 }
    	 }
     	 return -1;
     }
     
     public String toString() {
    	 return Arrays.toString(data);
     }
     
     public static void main(String[]args) {
    	 Scanner scanner = new Scanner(System.in);
    	 int searchInt;
    	 int position;
    	 
    	 System.out.print("Enter the number of integers to be displayed as an array\n");
    	 int numbers = scanner.nextInt();
    	 
    	 LinearArraySearch linearSearchArray = new LinearArraySearch(numbers);
    	 System.out.println(linearSearchArray.toString() + "\n"); //print array
    	 
    	 System.out.print("Please ENTER an integer value to search (-1 to quit)"); //read from console
    	 searchInt = scanner.nextInt();
    	 
    	 while(searchInt != -1) {
    		 position = linearSearchArray.linearSearch(searchInt);
    		 
    		 if(position == -1) {
    			 System.out.printf("\nThe integer "+searchInt+" was not found\n");
    		 }else {
    			 System.out.printf("\nThe integer "+searchInt+" was found in position "+position+"\n");
    		 }
    		 System.out.print("PLease ENTER an integer value to search (-1 to quit)");
    		 searchInt = scanner.nextInt();
    	 }
     }
}
