package Recussive;
import java.util.*;

public class BinaryArraySearch {
     private int[]data;
     private static final Random generator = new Random();
     
     public BinaryArraySearch(int size) {
    	 data = new int[size];
    	 for(int i = 0; i < size; i++) {
    		 data[i] = 10 + generator.nextInt(90);
    	 }
    	 Arrays.sort(data);
     }
     
     public int binarySearch(int searchKey) {
    	 int low = 0;
    	 int high = data.length - 1;
    	 int middle = (low + high + 1) / 2;
    	 int location = -1;
    	 
    	 do {
    		 if(searchKey == data[middle]) {
    			 location = middle;
    		 }else if(searchKey < data[middle]) {
    			 high = middle - 1;
    		 }else {
    			 low = middle + 1;
    		 }
    		 middle = (low + high + 1) / 2;
    	 }while ((low <= high) && (location == -1));
    	 return location;
     }
          
     public String toString() {
    	 return Arrays.toString(data);
     }
}
