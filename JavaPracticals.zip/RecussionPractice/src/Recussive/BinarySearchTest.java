package Recussive;
import java.util.*;

public class BinarySearchTest {
	public static void main(String[]args) {
	   Scanner scanner = new Scanner(System.in);
	   int searchInt;
	   int position;
	   
	   System.out.print("Enter the number of integers used for the search: ");
	   int number = scanner.nextInt();
	   
	   BinaryArraySearch binarySearchArray = new BinaryArraySearch(number);
	   System.out.println(binarySearchArray.toString() + "\n");
	   
	   System.out.print("Enter an integer value to search (-1 to quit) ");
	   searchInt = scanner.nextInt();
	   System.out.println();
	   
	   while(searchInt != -1) {
		   position = binarySearchArray.binarySearch(searchInt);
		   if(position == -1) {
			   System.out.println("The integer "+searchInt+" was not found\n");
		   }else {
			   System.out.println("The integer "+searchInt+" was found at position "+position+ "\n");
		   }
		   System.out.print("Enter an integer value to search (-1 to quit)");
		   searchInt = scanner.nextInt();
	   }
	}
}
