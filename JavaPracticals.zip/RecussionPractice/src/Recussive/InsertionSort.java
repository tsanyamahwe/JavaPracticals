package Recussive;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class InsertionSort {
    private int [] data;
    private static final Random generator = new Random();
    
    public InsertionSort(int size) {
    	data = new int[size];
    	for(int i = 0; i < size; i++) {
    		data[i] = 10 + generator.nextInt(90);
    	}
    }
    
    public void sort() {
    	int insert;
    	
    	for(int next = 1; next < data.length; next++) {
    		insert = data[next];
    		int moveItem = next;
    		while((moveItem > 0) && (data[moveItem - 1] > insert)) {
    			data[moveItem] = data[moveItem - 1];
    			moveItem--;
    		} 
    		data[moveItem] = insert;
    	}
    }
    
    public String toString() {
    	return Arrays.toString(data);
    }
    
    public static void main(String[]args) {
    	Scanner scanner = new Scanner(System.in);
    	
    	System.out.println("Enter the number of integers in an array");
    	int number = scanner.nextInt();
    	
    	InsertionSort insertionSort = new InsertionSort(number);
    	
    	System.out.println("Unsorted array: ");
    	System.out.println(insertionSort.toString() + "\n");
    	
    	insertionSort.sort();
    	
    	System.out.println("Sorted array: ");
    	System.out.println(insertionSort.toString() + "\n");
    }
}
