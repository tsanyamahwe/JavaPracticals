package Generics;

public class ListTest {
	public static void main(String[]args) {
		List<String> stringList = new List<String>();
		List<Integer> integerList = new List<Integer>();
		List<Double> doubleList = new List<Double>();
		
		stringList.insertAtFront("adriano");
		stringList.insertAtFront("adinho");
		stringList.insertAtBack("fabrinho");
		stringList.insertAtBack("herginho");
		stringList.print();
		
		System.out.println();
		
		integerList.insertAtFront(4);
		integerList.insertAtBack(7);
		integerList.insertAtBack(9);
		integerList.insertAtFront(1);
		integerList.print();
		
		System.out.println();
		
		doubleList.insertAtBack(2.4);
		doubleList.insertAtFront(5.1);
		doubleList.insertAtBack(6.2);
		doubleList.insertAtFront(8.9);
		doubleList.print();
		
		try {
			String removedItem = stringList.removeFromFront();
			System.out.printf("\n%s removed\n",removedItem);
			removedItem = stringList.removeFromBack();
			System.out.printf("%s removed\n", removedItem);
			stringList.print();
			
			System.out.println();
			
			int removeItem = integerList.removeFromFront();
			System.out.printf("\n%d removed\n", removeItem);
			removeItem = integerList.removeFromBack();
			System.out.printf("%d removed\n", removeItem);
			integerList.print();
			
			System.out.println();
			
			double removingItem = doubleList.removeFromFront();
			System.out.printf("\n%.1f removed\n", removingItem);
			removingItem = doubleList.removeFromBack();
			System.out.printf("%.1f removed\n", removingItem);
			doubleList.print();
		}catch(EmptyListException emptyListException) {
			System.err.println();
			emptyListException.printStackTrace();
		}
	}
}
