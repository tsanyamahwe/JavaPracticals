package Generics;

public class QueueInheritsList<T> extends List<T>{
	public QueueInheritsList() {
		super("Queue");
	}
	
	public void enqueue(T Object) {
		insertAtBack(Object);
	}
	
	//public T dequeue() throws EmptyListException{
	//	return removeFromFront();
	//}
	
	private static <T> void dequeueing(List<T> list) {
		try {
			T removedItem;
			while(true) {
				removedItem = list.removeFromFront();
				System.out.printf("\n%s \n", removedItem);
				list.print();
			}
		}catch(EmptyListException emptyListException) {
			System.err.println();
			emptyListException.printStackTrace();
		}
	}
	
	public static void main(String[]args) {
		QueueInheritsList<String> qilString = new QueueInheritsList<String>();
		QueueInheritsList<Integer> qilInteger = new QueueInheritsList<Integer>();
		QueueInheritsList<Double> qilDouble = new QueueInheritsList<Double>();
		
		qilString.enqueue("trio");
		qilString.enqueue("drio");
		qilString.enqueue("brio");
		qilString.print();
		
		dequeueing(qilString);
		
		qilInteger.enqueue(7);
		qilInteger.enqueue(9);
		qilInteger.enqueue(5);
		qilInteger.print();
		
		dequeueing(qilInteger);
		
		qilDouble.enqueue(3.5);
		qilDouble.enqueue(1.9);
		qilDouble.enqueue(6.1);
		qilDouble.print();
		
		dequeueing(qilDouble);
	}
}
