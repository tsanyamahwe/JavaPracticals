package Generics;

public class ListNode<T> {
	protected T data;
	protected ListNode<T> nextNode;
	
	protected ListNode(){
		this(null);
	}
	
	protected ListNode(T Object){
		this(Object, null);
	}
	
	protected ListNode(T Object, ListNode<T> node){
		data = Object;
		nextNode = node;
	}
	
	protected T getData() {
		return data;
	}
	
	protected ListNode<T> getNext(){
		return nextNode;
	}
}
