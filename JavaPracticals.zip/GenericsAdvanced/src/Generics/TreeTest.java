package Generics;
import java.util.*;

public class TreeTest {
	public static void main(String[]args) {
		Tree<Integer> integerTree = new Tree<Integer>();
		Tree<String> stringTree = new Tree<String>();
		Tree<Double> doubleTree = new Tree<Double>();
		
		int value;
		Random randomNumber = new Random();
		System.out.println("Inserting the following values: ");
		for(int i = 0; i <= 10; i++) {
			value = randomNumber.nextInt(100);
			System.out.printf("%d ", value);
			integerTree.insertNode(value);
		}
		
		System.out.println("\n\nPreorder traversal");
		integerTree.preorderTraversal();
		System.out.println();
		
		System.out.println("\n\nInorder traversal");
		integerTree.inorderTraversal();
		System.out.println();
		
		System.out.println("\n\nPostorder traversal");
		integerTree.postorderTraversal();
		
		String stringValue;
		Scanner scanner = new Scanner(System.in);
		System.out.println("\n\nInserting the following strings: ");
		for(int i = 0; i <= 6; i++) {
			stringValue = scanner.nextLine();
			System.out.printf("%s ", stringValue);
			stringTree.insertNode(stringValue);
		}
		
		System.out.println("\n\nPreorder traversal");
		stringTree.preorderTraversal();
		System.out.println();
		
		System.out.println("\n\nInorder traversal");
		stringTree.inorderTraversal();
		System.out.println();
		
		System.out.println("\n\nPostorder traversal");
		stringTree.postorderTraversal();
	}
}
