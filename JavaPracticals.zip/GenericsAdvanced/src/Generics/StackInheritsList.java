package Generics;

public class StackInheritsList<T> extends List<T>{
	public StackInheritsList() {
		super("stack");
	}
	
	public void push(T Object) {
		insertAtFront(Object);
	}
	
	/*public T pop() throws EmptyListException{
		return removeFromFront();
	}*/
	
	private static <T> void popping(List<T> list){
		try {
			T removedItem;
			while(true) {
				removedItem = list.removeFromFront();
				System.out.printf("\nPopped item: %s\n", removedItem);
				list.print();
			}
		}catch(EmptyListException emptyListException) {
			System.err.println();
			emptyListException.printStackTrace();
		}
	}
	
	public static void main(String[]args) {
		StackInheritsList<String> silString = new StackInheritsList<String>();
		StackInheritsList<Integer> silInteger = new StackInheritsList<Integer>();
		StackInheritsList<Double> silDouble = new StackInheritsList<Double>();
		
		silString.push("adrande");
		silString.push("abiola");
		silString.push("obomujo");
		silString.print();
		
		popping(silString);
		/*try {
			String removedItem;
			while(true) {
				removedItem = silString.pop();
				System.out.printf("\nPopped item: %s\n", removedItem);
				silString.print();
			}
		}catch(EmptyListException emptyListException) {
			System.err.println();
			emptyListException.printStackTrace();
		}*/
		
		silInteger.push(6);
		silInteger.push(9);
		silInteger.push(1);
		silInteger.print();
		
		popping(silInteger);
		/*try {
			int removedItem;
			while(true) {
				removedItem = silInteger.pop();
				System.out.printf("\nPopped item: %d\n", removedItem);
				silInteger.print();
			}
		}catch(EmptyListException emptyListException) {
				System.err.println();
				emptyListException.printStackTrace();
		}*/
		
		silDouble.push(4.7);
		silDouble.push(2.9);
		silDouble.push(7.1);
		silDouble.print();
		
		popping(silDouble);
		/*try {
			double removedItem;
			while(true) {
				removedItem = silDouble.pop();
				System.out.printf("\nPopped item: %.1f\n", removedItem);
				silDouble.print();
			}
		}catch(EmptyListException emptyListException) {
			System.err.println();
			emptyListException.printStackTrace();
		}*/
	}
}
