package Generics;

public class EmptyListException extends Throwable{
	public EmptyListException() {
		this("List");
	}
	
	public EmptyListException(String name) {
		super(name + " is empty");
	}
}
