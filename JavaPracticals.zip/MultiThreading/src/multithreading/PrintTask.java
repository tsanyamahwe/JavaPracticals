package multithreading;

public class PrintTask {

}
