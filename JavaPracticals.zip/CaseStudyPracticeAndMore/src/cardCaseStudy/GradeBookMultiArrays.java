package cardCaseStudy;

public class GradeBookMultiArrays {
	private String courseName;
	private int [][]gradeMarks;
	
	public GradeBookMultiArrays(String name, int [][] marks) {
		courseName = name;
		gradeMarks = marks;
	}
	
	public void setCourseName(String name) {
		courseName = name;
	}
	
	public String getCourseName() {
		return courseName;
	}
	
	public void displayMesssage() {
		System.out.printf("Welcome to Introduction to %S!\n", getCourseName());
	}
	
	public void processGrades() {
		outputGrades();
		System.out.printf("\nThe lowest mark is %d, and the highest mark is %d\n", getMinimum(), getMaximum());
		outputBarChart();
	}
	
	public void outputGrades() {
		System.out.println("\nThe marks are as follows:");
		System.out.print("             ");
		 
		for(int test = 0; test < gradeMarks[0].length; test++) {
			System.out.printf("Test %d  ", test + 1);
		}
		System.out.println("Average");
		
		for(int student = 0; student < gradeMarks.length; student++) {
			System.out.printf("Student %2d", student + 1);
			
			for(int test: gradeMarks[student]) {
				System.out.printf("%8d", test);
			}
			double average = getAverage(gradeMarks[student]);
			System.out.printf("%9.2f", average);
			System.out.println();
		}
	}
	
	 public double getAverage(int [] scoreMarks) {
		 int total = 0;
		 for(int grade: scoreMarks) {
			 total += grade;
		 }
		 return (double)total/scoreMarks.length;
	 }
	 
	public void outputBarChart() {
		System.out.println("\nDistribution of the Grades:");
		int [] frequency = new int [11];
		
		for(int [] studentMark: gradeMarks) {
			for(int grade: studentMark) {
				++frequency[grade/10];
			}
		}
		
		for(int count = 0; count < frequency.length; count++) {
			if(count == 10) {
				System.out.printf("%7d: ", 100);
			}else {
				System.out.printf("%02d - %02d: ", count * 10, count * 10 + 9);
			}
			
			for(int stars = 0; stars < frequency[count]; stars++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
	
	public int getMinimum() {
		int minimum = gradeMarks[0][0];
		for(int [] studentMark: gradeMarks) {
			for(int grade: studentMark) {
				if(grade < minimum) {
					minimum = grade;
				}
			}
		}
		return minimum;
	}
	
	public int getMaximum() {
		int maximum = gradeMarks[0][0];
		for(int [] studentMark: gradeMarks) {
			for(int grade: studentMark) {
				if(grade > maximum) {
					maximum = grade;
				}
			}
		}
		return maximum;
	}
	public static void main(String [] args) {
		int [][] marks = {{56,98,90},
				          {60,94,92},
				          {50,100,94},
				          {49,97,96},
				          {53,90,95},
				          {51,89,100},
				          {63,100,100},
				          {70,100,100},
				          {62,78,100},
				          {55,95,99}};
		GradeBookMultiArrays gbma = new GradeBookMultiArrays("Java Programming", marks);
		gbma.displayMesssage();
		gbma.processGrades();
	}
}
