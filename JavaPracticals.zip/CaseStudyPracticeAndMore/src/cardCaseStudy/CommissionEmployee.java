package cardCaseStudy;

public class CommissionEmployee {
   protected String firstName;
   protected String lastName;
   protected String socialSecurityNumber;
   protected double grossSales;
   protected double commissionRate;
   
   public CommissionEmployee(String name, String surname, String ssnumber, double sales, double rate) {
	   firstName = name;
	   lastName = surname;
	   socialSecurityNumber = ssnumber;
	   setGrossSales(sales);
	   setCommissionRate(rate);
   }
   
   public void setFirstName(String names) {
	   firstName = names;
   }
   
   public String getFirstName() {
	   return firstName;
   }
   
   public void setLastName(String surnames) {
	   lastName = surnames;
   }
   
   public String getLastName() {
	   return lastName;
   }
   
   public void setSSNumber(String ssnumbers) {
	   socialSecurityNumber = ssnumbers;
   }
   
   public String getSSNumber() {
	   return socialSecurityNumber;
   }
   
   public void setGrossSales(double sales) {
	   if(sales > 0.0) {
		   grossSales = sales;
	   }else {
		   throw new IllegalArgumentException("Gross Sales must be > 0.0");
	   }
   }
   
   public double getGrossSales() {
	   return grossSales;
   }
   
   public void setCommissionRate(double rate) {
	   if (0.0 < rate && rate < 1.0) {
		   commissionRate = rate;
	   }else {
		   throw new IllegalArgumentException("Commision rate must be between 0.0 - 1.0");
	   }
   }
   
   public double getCommissionRate() {
	   return commissionRate;
   }
   
   public double earnings() {
	   return commissionRate * grossSales;
   }
   
   public String toString() {
	   return String.format("%s: %s %s\n%s: %s\n%s: %.2f\n%s: %.2f",
			   "Commissioned Employee", firstName, lastName, "Social Security Number", socialSecurityNumber,
			   "Gross Sales", grossSales, "Commission Rate", commissionRate);
   }
   
   public static void main (String [] args) {
	   CommissionEmployee comEmp = new CommissionEmployee("Sue","Jones","222-222-222",10000, .06);
	   System.out.println("Employee information obtained by get Methods:");
	   System.out.printf("%s %s\n", "First name is: ", comEmp.getFirstName());
	   System.out.printf("%s %s\n", "Surname is: ", comEmp.lastName);
	   System.out.printf("%s %s\n", "Social Security Number is: ", comEmp.getSSNumber());
	   System.out.printf("%s %.2f\n", "Gross Sales is: ", comEmp.getGrossSales());
	   System.out.printf("%s %.2f\n", "Commission rate is: ", comEmp.getCommissionRate());
	   
	   comEmp.setGrossSales(20000);
	   comEmp.setCommissionRate(.1);
	   
	   System.out.printf("\n%s: \n\n%s\n", "Updated employee information obtained by toString", comEmp);
   }
}
