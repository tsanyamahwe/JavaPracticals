package cardCaseStudy;
import java.util.*;

public class Time2 {
	private int hour;
	private int minute;
	private int second;
	
	public Time2() {this(0,0,0);}
	public Time2(int h) {this(h,0,0);}
	public Time2(int h, int m) {this(h,m,0);}
	public Time2(int h, int m, int s) {setTime(h,m,s);}
	public Time2(Time2 time) {this(time.getHour(), time.getMinute(), time.getSecond());}
	public void setTime(int h, int m, int s) {setHour(h);setMinute(m);setSecond(s);}
	public void setHour(int h) {if (0 <= h && h < 24) {hour = h;}else {throw new IllegalArgumentException ("hours must be 0-23");}}
	public void setMinute(int m) {if (0 <= m && m < 60) {minute = m;}else {throw new IllegalArgumentException ("minutes must be 0-59");}}
	public void setSecond(int s) {if (0 <= s && s < 60) {second = s;}else {throw new IllegalArgumentException ("seconds must be 0-59");}}
	public int getHour() {return hour;}
	public int getMinute() {return minute;}
	public int getSecond() {return second;}
	public String toUniversalString() {return String.format("%02d:%02d:%02d", getHour(), getMinute(), getSecond());}
	public String toString() {return String.format("%d:%02d:%02d %s", ((getHour()==0||getHour()==12)?12:getHour()%12), 
			getMinute(), getSecond(),(getHour()<12?"AM":"PM"));}
	
	public static void main (String[] args) {
		Time2 t1 = new Time2();
		Time2 t2 = new Time2(2);
		Time2 t3 = new Time2(21, 34);
		Time2 t4 = new Time2(12, 25, 42);
		Time2 t5 = new Time2(t4);
		
		System.out.println("Constructed with:");
		System.out.println("t1: All arguments defaulted");
		System.out.printf(" %s\n", t1.toUniversalString());
		System.out.printf(" %s\n", t1.toString());
		System.out.println();
		
		System.out.println("t2: Hour set, Minute and Second is default");
		System.out.printf(" %s\n", t2.toUniversalString());
		System.out.printf(" %s\n",t2.toString());
		System.out.println();
		
		System.out.println("t3: Hour and Minute set, second is default");
		System.out.printf(" %s\n", t3.toUniversalString());
		System.out.printf(" %s\n", t3.toString());
		System.out.println();
		
		System.out.println("t4:Hour, Minute, Second specified");
		System.out.printf(" %s\n", t4.toUniversalString());
		System.out.printf(" %s\n", t4.toString());
		System.out.println();
		
		System.out.println("t5: Time2 t4 Object specified");
		System.out.printf(" %s\n", t5.toUniversalString());
		System.out.printf(" %s\n", t5.toString());
		
		try {
			Time2 t6 = new Time2(26, 71, 84);
		}catch(IllegalArgumentException e){
			System.out.printf("\nException while initialising t6: %s", e.getMessage());
		}
	}
}

