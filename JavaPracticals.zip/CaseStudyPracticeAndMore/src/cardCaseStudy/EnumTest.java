package cardCaseStudy;
import java.util.*;

public class EnumTest {
	public static void main (String [] args) {
		System.out.println("All books:");
		//print ALL books
		for(Book book: Book.values()) {
			System.out.printf("%-11s%-45s%s\n", book, book.getTitle(), book.getCopyRightYear());
		}
		System.out.println();
		System.out.println("Displaying a range of Books:");
		//print a RANGE of books
		for(Book book: EnumSet.range(Book.JHTP, Book.CPPHTP)) {
			System.out.printf("%-11s%-45s%s\n", book, book.getTitle(), book.getCopyRightYear());
		}
	}
}
