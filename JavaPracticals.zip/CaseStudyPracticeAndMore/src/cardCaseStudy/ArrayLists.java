package cardCaseStudy;
import java.util.*;

public class ArrayLists {
	
	public static void display (ArrayList<String> list, String header) {
		System.out.print(header);
		
		for(String listed: list) {
			System.out.printf("%s ", listed);
		}
	}
   public static void main (String []args) {
	   ArrayList<String> items = new ArrayList<String>();
	   items.add("red");
	   items.add(0, "yellow");
	   
	   System.out.print("Display the List with counter controlled loop: ");
	   
	   for (int i = 0; i < items.size(); i++) {
		   System.out.printf("%s ", items.get(i));
	   }
	   
	   System.out.print("\nDisplay the List with enhanced for-loop: ");
	   items.add("green");
	   items.add("yellow");
	   display(items,"\nList with 2 new elements: ");
	   
	   items.remove("yellow");
	   display(items, "\nRemoved 1st instance of yellow now shows: ");
	   
	   items.remove(1);
	   display(items, "\nRemoved the second list element (green): ");
	   
	   System.out.printf("\n\"red\" is %s in the list\n ", items.contains("red")?"":"not ");
	   //items.contains(("red")? "":"not ");
	   
	   System.out.printf("%s is the Size of the list", items.size());
	}
}
