package cardCaseStudy;

public class Time {
    private int hour;
    private int minute;
    private int second;
    
    public void setTime(int h, int m, int s) {
    	if((0 < h && h < 24) &&  ( 0 < m && m  <60) && (0 < s && s < 60)){
    		hour = h;
    		minute = m;
    		second = s;
    	}else {
    		throw new IllegalArgumentException("hour, minute, second out of range");
    	}
    }
    
    public String toUniversalString() {
    	return String.format("%02d:%02d:%02d", hour, minute, second);
    }
    
    public String toString() {
    	return String.format(("%d:%02d:%02d %s"), ((hour == 0||hour ==12) ? 12:hour % 12), minute, second, (hour < 12 ? "AM":"PM"));
    }
    
    public static void main (String [] args) {
    	Time time = new Time();

        System.out.print("The initial Universal time is: ");
        System.out.println(time.toUniversalString());
        System.out.print("The initial Standard time is: ");
        System.out.println(time.toString());
        System.out.println();
        
        time.setTime(14, 4, 45);
        System.out.print("The set Universal time is: ");
        System.out.println(time.toUniversalString());
        System.out.print("The set Standard time is: ");
        System.out.println(time.toString());
        
        try {
        	time.setTime(69, 89, 70);
        }catch(IllegalArgumentException e){
            System.out.printf("\nException: %s\n\n", e.getMessage());
        }
        
        System.out.print("After attempting invalid settings; Universal time is: ");
        System.out.println(time.toUniversalString());
        System.out.print("\nAfter attempting invalid setiings; Standard time is: ");
        System.out.println(time.toString());
    }
}
