package cardCaseStudy;
import java.util.*;

public class DeckOfCards {
	private static final Random randomNumbers = new Random();
	
	private Card [] deck;
	private int currentCard;
	private static final int NUMBER_OF_CARDS = 52;
	
	public DeckOfCards()
	{
		String [] face = {"Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack", "King", "Queen"};
		String [] suit = {"Hearts", "Diamonds", "Spades", "Clubs"};
		
		deck = new Card[NUMBER_OF_CARDS];
		currentCard = 0;
		
		for (int counter = 0; counter < deck.length; counter++)
		{
			deck[counter] = new Card(face[counter % 13], suit[counter / 13]);
		}
	}
	
	public void shuffleCards()
	{
		currentCard = 0;
		
		for (int firstCard = 0; firstCard < deck.length; firstCard++)
		{
			int secondCard = randomNumbers.nextInt(NUMBER_OF_CARDS);
			
			Card temp = deck[firstCard];
			deck[firstCard] = deck[secondCard];
			deck[secondCard] = temp;
		}
	}
	
	public Card cardDealing()
	{
		if (currentCard < deck.length)
		{
			return deck[currentCard++];
		}else
		{
			return null;
		}
	}
}
