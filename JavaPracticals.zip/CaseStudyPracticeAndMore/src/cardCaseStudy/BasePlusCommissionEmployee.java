package cardCaseStudy;

public class BasePlusCommissionEmployee extends CommissionEmployee {
     private double baseSalary;
     
     public BasePlusCommissionEmployee(String first, String last, String ssn, double sales, double rate, double salary) {
    	 super(first, last, ssn, sales, rate);
    	 baseSalary = salary;
     }
     
     public void setBaseSalary(double salary) {
    	 if(salary >= 0) {
    		 baseSalary = salary;
    	 }else {
    		 throw new IllegalArgumentException("Base salary must be >= 0");
    	 }
     }
     
     public double getBaseSalary() {
    	 return baseSalary;
     }
     
     @Override
     public double earnings() {
    	 return baseSalary + super.earnings();
     }
     
     @Override
     public String toString() {
    	 return String.format("%s %s\n%s %.2f\n","Base Salaried Plus", super.toString(),"Base Salary", getBaseSalary());
   
     }
     
     public static void main (String [] args) {
    	 BasePlusCommissionEmployee bpce = new BasePlusCommissionEmployee("Rose", "Bale", "333-333-333", 20000.00, 0.1, 9000.00);
    	 CommissionEmployee cme = new CommissionEmployee("Sandra", "Blade", "444-444-444", 15000.00, 0.3);
    	 CommissionEmployee cme2 = new BasePlusCommissionEmployee("Tracy", "Champs", "111-111-111", 15000.00, 0.3, 12000.00);
    	 //BasePlusCommissionEmployee bpce2 = new CommissionEmployee("Role", "Nead", "222-222-222",  16000.00, 0.4, 7000.00);
    	 
    	 System.out.printf("%s %s:\n\n%s\n\n", "Call CommissionEmployee's toString with superclass reference", "to superclass object", cme.toString());
    	 System.out.printf("%s %s:\n\n%s\n\n", "Call BasePlusCommissionEmployee's toString with subclass reference", "to subclass object", bpce.toString());
    	 System.out.printf("%s %s:\n\n%s\n\n", "Call BasePlusCommissionEmployee's toString with superclass reference", "to subclass object", cme2.toString());
     }
}
