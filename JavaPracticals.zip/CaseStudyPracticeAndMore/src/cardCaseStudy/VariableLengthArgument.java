package cardCaseStudy;
import java.util.*;

public class VariableLengthArgument {
     
	public static void displayArray(int [] array, String description) {
		System.out.printf("\n%s", description);
		
		for (int value: array) {
			System.out.printf("%d", value);
		}
	}
	public static void main (String [] args) {
		double [] doubleArray = {1.75,2.81,3.77,1.23,4.39};
		Arrays.sort(doubleArray);
		System.out.print("\ndoubleArray: ");
		
		for(double value: doubleArray) {
			System.out.printf("%.2f ", value);
		}
		
		int [] filledArray = new int [10];
		Arrays.fill(filledArray, 7);
		displayArray(filledArray, "filledArray: ");
		
		int [] array = {1,2,3,4,5,6};
		int [] copiedArray = new int [array.length];
		System.arraycopy(array, 0, copiedArray, 0, array.length);
		displayArray(array, "array: ");
		displayArray(copiedArray, "copiedArray: ");
		
		boolean b = Arrays.equals(array, copiedArray);
		System.out.printf("\n\narray %s copiedArray\n", (b? "==":"!="));
		b = Arrays.equals(array, filledArray);
		System.out.printf("array %s filledArray\n", (b? "==":"!="));
		
		int location = Arrays.binarySearch(array, 5);
		if(location >= 0) {
			System.out.printf("Found 5 at element %d in array\n", location);
		}else {
			System.out.printf("5 not found in the array");
		}
		
		location =Arrays.binarySearch(array, 8);
		if(location >= 0) {
			System.out.printf("Found 8 at element %d in array\n", location);
		}else {
			System.out.printf("8 was not found in the array");
		}
	}	
}
