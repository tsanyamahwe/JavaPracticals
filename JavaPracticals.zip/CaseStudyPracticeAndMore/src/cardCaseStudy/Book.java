package cardCaseStudy;
import java.util.*;

public enum Book {
	 
	 JHTP("Java How To Program", "2012"),
	 CHTP("C: How To Program", "2007"),
	 IW3HTP("Internet & World Wide Web How To Program", "2008"),
	 CPPHTP("C++ How To Program", "2012"),
	 VBHTP("Visual Basic 2010 How To Program", "2011"),
	 CSHARPHTP("C# 2010 How To Program", "2011");
	 
	 private final String title;
	 private final String copyRightYear;
	 
	 Book(String bookTitle, String year) {
		 title = bookTitle;
		 copyRightYear = year;
	 }
	 
	 public String getTitle() {
		 return title;
	 }
	 
	 public String getCopyRightYear() {
		 return copyRightYear;
	 }
}
