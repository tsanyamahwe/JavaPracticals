package cardCaseStudy;

public class GradeBookCase2 {
   private String courseName;
   private int [][] grades;
   private double average;
   
   public GradeBookCase2(String name, int [][] grade) {
	   courseName = name;
	   grades = grade;
   }
   
   public void setCourseName(String name) {
	   courseName = name;
   }
   
   public String getCourseName() {
	   return courseName;
   }
   
   public void displayMessage() {
	   System.out.printf("Welcome to Introduction to %s", getCourseName());
   }
   
   public void processGrades() {
	   outputGrades();
	   System.out.printf("\nThe average mark is %.2f\n", average);
	   System.out.printf("The Lowest grade is %d, and the Highest grade is %d\n", getMinimum(), getMaximum());
	   outputBarChart();
   }
   
   public int getMinimum() {
	   int lowGrade = grades [0][0];
	   for(int [] studentGrade: grades) {
		   for (int grade: studentGrade) {
			   if (grade < lowGrade) {
				   lowGrade = grade;
			   }
		   }
	   }
	   return lowGrade;
   }
   
   public int getMaximum() {
	   int highGrade = grades [0][0];
	   for (int [] studentGrade: grades) {
		   for (int grade: studentGrade) {
			   if(grade > highGrade) {
				   highGrade = grade;
			   }
		   }
	   }
	   return highGrade;
   }
   
   public double getAverage(int [] setofGrades) {
	   int total = 0;
	   for (int grade: setofGrades) {
		   total += grade;
	   }
	   return (double)total/setofGrades.length;
   }
   
   /*public double getAverage() {
	   int total = 0;
	   for (int [] studGrade: grades) {
		   for (int grade: studGrade) {
			   total += grade;
		   }
	   }
	   return (double) total/grades.length;
   }*/
   
   public void outputBarChart() {
	   System.out.println("\nOveral distribution of the Grades:");
	   int [] frequency = new int [11];
	   
	   for(int [] studentGrades: grades) {
		   for(int grade: studentGrades) {
			   ++frequency[grade/10];
		   }
	   }
	   
	   for (int count = 0; count < frequency.length; count++) {
		   if(count == 10) {
			   System.out.printf("%7d: ", 100);
		   }
		   else {
			   System.out.printf("%02d - %02d: ", count * 10, count * 10 + 9);
		   }
		   
		   for (int stars = 0; stars <frequency[count]; stars++) {
			   System.out.print("*");
		   }
		   System.out.println();
	   }
   }
   
   public void outputGrades() {
	   System.out.println("The grades are:\n");
	   System.out.print("              ");
	   
	   // creating a column heading for each test
	   for (int test = 0; test < grades[0].length; test++) {
		   System.out.printf("Test %d  ", test + 1);
	   }
	   System.out.println("Average");
	   
	   //System.out.println("Average");
	   
	   for (int student = 0; student < grades.length; student++) {
		   System.out.printf("Student %2d", student + 1);
		   
		   for (int test: grades[student]) {
			   System.out.printf("%8d", test);
		   }
		   average = getAverage(grades[student]);
		   System.out.printf("%9.2f", average);
		   System.out.println();
	   }
   }
   
   public static void main (String [] args ) {
	   int [][] gradesArray = {{87,94,90},
			                   {90,91,92},
	                           {72,100,96},
			                   {64,88,99},
			                   {93,92,91},
			                   {96,94,93},
			                   {89,90,91},
			                   {94,96,98},
			                   {100,96,92},
			                   {89,92,95}};
	   GradeBookCase2 myGradeBookCase2 = new GradeBookCase2("Java Programming!\n", gradesArray);
	   myGradeBookCase2.displayMessage();
	   myGradeBookCase2.processGrades();
   }
}
