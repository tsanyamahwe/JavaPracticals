package generics;

public class StackTest {
	private static void testPushDouble(Stack<Double> stack, double[] values) {
		System.out.println("\nPushing Stack into doubleStack");
		for(double value: values) {
			System.out.printf("%.1f ", value);
			stack.push(value);
		}
	}
	
	private static void testPopDouble(Stack<Double> stack) {
		try {
			System.out.println("\nPopping elements from doubleStack");
			double popValue;
			while(true) {
				popValue = stack.pop();
				System.out.printf("%.1f ", popValue);
			}
		}catch(EmptyStackException emptyStackException) {
			System.err.println();
			emptyStackException.printStackTrace();
		}
	}
	
	private static void testPushInteger(Stack<Integer> stack, int [] values) {
		System.out.println("\nPushing Stack into integerStack");
		for(int value: values) {
			System.out.printf("%d ", value);
			stack.push(value);
		}
	}
	
	private static void testPopInteger(Stack<Integer> stack) {
		try {
			System.out.println("\nPopping elements fron integerStack");
			int popValue;
			while(true) {
				popValue = stack.pop();
				System.out.printf("%d ", popValue);
			}
		}catch(EmptyStackException emptyStackException) {
			System.err.println();
			emptyStackException.printStackTrace();
		}
	}
	
	private static void testPushString(Stack<String> stack, String[] values) {
		System.out.println("Pushing elements into stringStack");
		for(String value: values) {
			System.out.printf("%s", value);
			stack.push(value);
		}
	}
	
	private static void testPopString(Stack<String> stack) {
		try {
			System.out.println("\nPopping elements from the stringStack");
			String popValue;
			while(true) {
				popValue = stack.pop();
			}
		}catch(EmptyStackException emptyStackException) {
			System.err.println();
			emptyStackException.printStackTrace();
		}
	}
	
	public static void main(String[]args) {
		double[] doubleElements = {2.7, 3.8, 4.9, 5.2, 6.4};
		int [] intElements = {3, 4, 5, 6, 7, 8};
		String [] stringElements = {"robina", "jordina", "ledina", "fordina", "berlina", "derlina"};
		
		Stack<Double> doubleStack = new Stack<Double>(5);
		Stack<Integer> integerStack = new Stack<Integer>();
		Stack<String> stringStack = new Stack<String>(6);
		
		testPushDouble(doubleStack, doubleElements);
		testPopDouble(doubleStack);
		
		testPushInteger(integerStack, intElements);
		testPopInteger(integerStack);
		
		testPushString(stringStack, stringElements);
		testPopString(stringStack);
	}
}
