package generics;
import java.util.*;;

public class GenericsAddition {
	private static double sum(List<? extends Number> list) {
		double total = 0;
		for(Number element: list) {
			total += element.doubleValue();
		}
		return total;
	}
	
	public static void main(String[]args) {
		Number[] numbers = {2.4, 5, 6.7, 8, 1.3, 9, 6, 3.9};
		List<Number> list = new ArrayList<Number>(Arrays.asList(numbers));
		
		Integer[] intNumbers = {2, 3, 4, 5, 16, 7,8, 19, 30};
		List<Integer> intList = new ArrayList<Integer>(Arrays.asList(intNumbers));
		
		Double[] doubleNumbers = {1.2, 2.3, 3.4, 4.5, 5.6, 6.7};
		List<Double> doubleList = new ArrayList<Double>(Arrays.asList(doubleNumbers));
		
		System.out.printf("The list consist of %s\n", list);
		System.out.printf("Total of the numbers in the list is %.1f\n", sum(list));
		
		System.out.printf("\nThe integer list consist of %s\n", intList);
		System.out.printf("Total of the numbers in the integer list is %.1f\n", sum(intList));
		
		System.out.printf("\nThe double list consist of %s\n", doubleList);
		System.out.printf("Total of the numbers in the double list is %.1f", sum(doubleList));
	}
}
