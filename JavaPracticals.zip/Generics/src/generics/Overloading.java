package generics;

public class Overloading {
   private static void printArray(Object[] inputArray) {
	   for(Object array: inputArray) {
		   System.out.printf("%s ", array);
	   }
	   System.out.println();
   }
   
   public static void main(String[]args) {
	   Integer[] intArray = {12, 45, 56, 37, 78, 34, 12, 89, 76, 71};
	   String[] stringArray = {"alpha", "romio", "proud", "roland", "perculiar"};
	   Character[] charArray = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'K', 'L', 'M', 'N', 'O', 'P'};
	   Double[] doubleArray = {1.2, 3.7, 4.5, 6.9, 4.8, 5.5, 7.1, 9.0, 2.7, 8.3};
	   
	   System.out.println("Array IntegerArray contains:");
	   printArray(intArray);
	   System.out.println("Array StringArray contains:");
	   printArray(stringArray);
	   System.out.println("Array CharacterArray contains:");
	   printArray(charArray);
	   System.out.println("Array DoubleArray contains:");
	   printArray(doubleArray);
   }
}
