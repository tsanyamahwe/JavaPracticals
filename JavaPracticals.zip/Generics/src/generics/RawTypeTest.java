package generics;

public class RawTypeTest {
	private static <Object> void testPush(String name, Stack<Object> stack, Object[] elements) {
		System.out.printf("\nPushing elements into the %s\n", name);
		for(Object element: elements) {
			System.out.printf("%s ", element);
			stack.push(element);
		}
	} 
	
	private static <Object> void testPop(String name, Stack<Object> stack) {
		try {
			System.out.printf("\nPopping elements out of the %s\n", name);
			Object popValue;
			while(true) {
				popValue = stack.pop();
				System.out.printf("%s ", popValue);
			}
		}catch(EmptyStackException emptyStackException) {
			System.err.println();
			emptyStackException.printStackTrace();
		}
	}
	
	public static void main(String[]args) {
		Double[] doubleElements = {2.3, 3.4, 4.5, 5.6, 6.7, 7.8};
		Integer[] integerElements = {2, 3, 4, 5, 6, 7, 8};
		String[] stringElements = {"Tri", "Brio", "Prio", "Crio", "Orio"};
		
		Stack rawTypeStack1 = new Stack(7);
		Stack rawTypeStack2 = new Stack<Double>(7);
		Stack rawTypeStack3 = new Stack<String>(5);
		Stack<Integer> integerStack = new Stack<Integer>();
		
		testPush("rawTypeStack1", rawTypeStack1, doubleElements);
		testPop("rawTypeStack1", rawTypeStack1);
		testPush("rawTypeStack2", rawTypeStack2, doubleElements);
		testPop("rawTypeStack2", rawTypeStack2);
		testPush("integerStack", integerStack, integerElements);
		testPop("integerStack", integerStack);
		testPush("rawTypeStack3", rawTypeStack3, stringElements);
		testPop("rawTypeStack3", rawTypeStack3);
	}
}
