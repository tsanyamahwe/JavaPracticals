package generics;

public class GenericStackTest {
	private static <Object> void testPush(String name, Stack<Object> stack, Object[]elements) {
		System.out.printf("\nPushing elements into the %s\n", name);
		for(Object element: elements) {
			System.out.printf("%s ", element);
			stack.push(element);
		}
	}
	
	private static <Object> void testPop(String name, Stack<Object> stack) {
		try {
		System.out.printf("\nPopping elements out the %s\n", name);
		Object popValue;
		while(true) {
			popValue = stack.pop();
			System.out.printf("%s ", popValue);
		}
		}catch(EmptyStackException emptyStackException) {
			System.err.println();
			emptyStackException.printStackTrace();
		}
	}
	
	public static void main(String[]args) {
		Double[] doubleElements = {2.7, 3.8, 4.9, 5.2, 6.4};
		Integer [] intElements = {3, 4, 5, 6, 7, 8, 9, 1, 2, 10};
		String [] stringElements = {"\"Rorbina\"", "\"Jordina\"", "\"Ledina\"", "\"Fordina\"", "\"Berlina\"", "\"Derlina\""};
		
		Stack<Double> doubleStack = new Stack<Double>(5);
		Stack<Integer> integerStack = new Stack<Integer>();
		Stack<String> stringStack = new Stack<String>(6);
		
		testPush("doubleStack", doubleStack, doubleElements);
		testPop("doubleStack", doubleStack);
		
		testPush("integerStack", integerStack, intElements);
		testPop("integerStack", integerStack);
		
		testPush("stringStack", stringStack, stringElements);
		testPop("stringStack", stringStack);
	}
}
