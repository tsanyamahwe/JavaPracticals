package generics;
import java.util.*;

public class Stack<T> {
	private List<T> elements;
	
	public Stack() {
		this(10);
	}
	
	public Stack(int capacity) {
		int initialCapacity = capacity > 0? capacity: 10;
		elements = new ArrayList<T>(initialCapacity);
	}
	
	public void push(T pushValue) {
		elements.add(pushValue);
	}
	
	public T pop() {
		if(elements.isEmpty()) {
			throw new EmptyStackException("Stack is empty, cannot pop");
		}
		return elements.remove(elements.size() - 1);
    }
}
