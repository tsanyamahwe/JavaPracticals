/**
 * 
 */
/**
 * 
 */
module FilesStreamsObjectsAndSerialization {
}