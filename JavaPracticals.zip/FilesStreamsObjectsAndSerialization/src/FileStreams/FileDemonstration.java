package FileStreams;
import java.util.*;
import java.io.*;

public class FileDemonstration {
    public static void analysePath(String path) {
    	File name = new File(path);
    	if(name.exists()) { //display file (or directory) information
    		System.out.printf("%s%s\n%s\n%s\n%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s",
    				name.getName(), " exists",
    				(name.isFile()? "is a file":"is not a file"),
    				(name.isDirectory()? "is a directory":"is not directory"),
    				(name.isAbsolute()? "is absolute path":"is not absolute path"),
    				"Last modified:", name.lastModified(),
    				"Length:", name.length(),
    				"Path:", name.getPath(),
    				"Absolute Path:", name.getAbsolutePath(),
    				"Parent:", name.getParent());
    	    if(name.isDirectory()) { //output directory listing
    	    	String[]directory = name.list();
    	    	System.out.print("\n\nDirectory contents:\n");
    	    	for(String directoryName: directory) {
    	    		System.out.print(directoryName);
    	    	}
    	    }
    	}else {
    		System.out.printf("%s %s", path, "does not exist");
    	}
    }
	public static void main(String [] args) {
    	Scanner scanner = new Scanner(System.in);
    	System.out.print("Enter file or directory name: ");
    	analysePath(scanner.nextLine());
    }
}
