package FileStreams;

public class CredityInquiryTest {
   public static void main(String[]args) {
	   CredityInquiry application = new CredityInquiry();
	   application.processRequest();
   }
}
