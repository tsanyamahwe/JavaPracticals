package FileStreams;

public class AccountRecord {
    private int account;
    private String firstName;
    private String lastName;
    private double balance;
    
    public AccountRecord() {
    	this(0,"","",0.0);
    }
    
    public AccountRecord(int acc, String name, String surname, double bal) {
    	setAccount(acc);
    	setFirstName(name);
    	setLastName(surname);
    	setBalance(bal);
    }
    
    public void setAccount(int acc) {
    	account = acc;
    }
    
    public int getAccount() {
    	return account;
    }
    
    public void setFirstName(String name) {
    	firstName = name;
    }
    
    public String getFirstName() {
    	return firstName;
    }
    
    public void setLastName(String surname) {
    	lastName = surname;
    }
    
    public String getLastName() {
    	return lastName;
    }
    
    public void setBalance(double bal) {
    	balance = bal;
    }
    
    public double getBalance() {
    	return balance;
    }
}
