package FileStreams;
import java.io.*;
import java.util.*;

public class CreateTextFile {
   private Formatter output; //object used to output text to a file
   
   public void openFile() { //enable a user to open a file
	   try {
		   output = new Formatter(new File("clients.txt")); //open file
	   }catch(SecurityException securityExeption) {
		   System.err.println("You dont have write access this file");
		   System.exit(1);
	   }catch(FileNotFoundException fileNotFoundException) {
		   System.err.println("Error opening or creating file");
		   System.exit(1);
	   }
   }
   
   public void addRecords() {
	   AccountRecord record = new AccountRecord();
	   Scanner scanner = new Scanner(System.in);
	   
	   System.out.printf("%s\n%s\n%s\n\n",
			   "To terminate, type an end-of-file indicator when prompted to enter input:",
			   "1. On UNIX/Linux/Mac OS X type <ctrl> d then press Enter",
			   "2. On Windows type <ctrl> z then press Enter");
	   
	   System.out.printf("%s OR %s\n", "Enter account number (> 0), first name, surname and balance.", "?");
	   
	   while(scanner.hasNext()) {
		   try {
			   record.setAccount(scanner.nextInt());
			   record.setFirstName(scanner.next());
			   record.setLastName(scanner.next());
			   record.setBalance(scanner.nextDouble());
			   
			   if(record.getAccount() > 0) {
				   output.format("%-10d %-12s %-12s %-10.2f\n", record.getAccount(), record.getFirstName(), record.getLastName(), record.getBalance());
			   }else {
				   System.out.println("Account number must be greater than 0");
			   }
		   }catch(FormatterClosedException formatterClosedException) {
			   System.err.println("Error writing to the file");
			   scanner.close();
			   return;
		   }catch(NoSuchElementException noSuchElementException) {
			   System.err.println("Invalid input. Please try again");
			   scanner.nextLine();
		   }
		   System.out.printf("%s OR %s\n", "Enter account number, first name, surname and balance.", "?");
	   }
	   scanner.close();
   }
   
   public void closeFile() {
	   if(output != null) {
		   output.close();
	   }
   }
}
