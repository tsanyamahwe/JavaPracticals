package FileStreams;
import java.io.FileNotFoundException;
import java.util.*;
import java.io.File;

public class CredityInquiry {
	private MenuOption accountTypes;
	private Scanner scanner;
	private static final MenuOption[]choices = {MenuOption.ZERO_BALANCE, MenuOption.CREDIT_BALANCE, MenuOption.DEBIT_BALANCE, MenuOption.END};
	
	private enum MenuOption{
		ZERO_BALANCE(1), 
		CREDIT_BALANCE(2), 
		DEBIT_BALANCE(3),
		END(4);
		
		private final int valueOption;
		
		MenuOption(int value) {
			valueOption = value;
		}
	}
	
	public void processRequest() {
		accountTypes = getRequest();
		if(accountTypes != MenuOption.END) {
			switch(accountTypes) {
			   case ZERO_BALANCE:
				   System.out.println("\nAccounts with ZERO balance:\n");
				   break;
			   case CREDIT_BALANCE:
				   System.out.println("\nAccounts with CREDIT balance:\n");
				   break;
			   case DEBIT_BALANCE:
				   System.out.println("\nAccounts with DEBIT balance:\n");
				   break;
			}
		}else {
			System.exit(1);
		}
		readRecords();
		accountTypes = getRequest();
	}
	
	private MenuOption getRequest() {
		scanner = new Scanner(System.in);
		int request = 1;
		
		System.out.printf("%s\n%s\n%s\n%s\n%s\n",
				"Enter Request:",
				"1: List accounts with ZERO balances",
				"2: List accounts with CREDIT balances",
				"3: List accounts with DEBIT balances",
				"4: End");
		try {
			do {
				System.out.print("\n");
				request = scanner.nextInt();
			}while((request < 1) && (request > 4));
		}catch(NoSuchElementException noSuchElementException) {
			System.err.println("Invalid Input");
			System.exit(1);
		}
		return choices[request -1];
	}
	
	private void readRecords() {
		AccountRecord record = new AccountRecord();
		
		try {
			scanner = new Scanner(new File("clients.txt"));
			
			record.setAccount(scanner.nextInt());
			record.setFirstName(scanner.next());
			record.setLastName(scanner.next());
			record.setBalance(scanner.nextDouble());
			
			if(shouldDisplay(record.getBalance())) {
				System.out.printf("%-10d %-12s %-12s %-10.2f", record.getAccount(), record.getFirstName(), record.getLastName(), record.getBalance());
			}
		}catch(NoSuchElementException noSuchElementException) {
			System.err.println("Files improperly formed");
			System.exit(1);
		}catch(FileNotFoundException fileNotFoundException) {
			System.err.println("File not found");
		}catch(IllegalStateException illegalStateException) {
			System.err.println("Error reading the file");
		}finally {
			if(scanner != null) {
				scanner.close();
			}
		}
	}
	
	private boolean shouldDisplay(double balance) {
		if(accountTypes == MenuOption.ZERO_BALANCE && balance == 0) {
			return true;
		}else if(accountTypes == MenuOption.CREDIT_BALANCE && balance < 0) {
			return true;
		}else if(accountTypes == MenuOption.DEBIT_BALANCE && balance > 0) {
			return true;
		}
		return false;
	}
}
