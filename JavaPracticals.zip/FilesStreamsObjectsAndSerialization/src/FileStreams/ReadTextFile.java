package FileStreams;
import java.io.*;
import java.lang.*;
import java.util.*;

public class ReadTextFile {
    private Scanner scanner;
    
    public void openFile() {
    	try {
    		 scanner = new Scanner(new File("clients.txt"));
    	}catch(FileNotFoundException fileNotFoundException) {
    		System.err.println("Error opening file");
    		System.exit(1);
    	}
    }
    
    public void readRecords() {
    	AccountRecord record = new AccountRecord();
    	
    	System.out.printf("%-10s%-12s%-12s%-10s\n", "Account","Name","Surname","Balance");
    	
    	try {
    		while(scanner.hasNext()) {
    			record.setAccount(scanner.nextInt());
    			record.setFirstName(scanner.next());
    			record.setLastName(scanner.next());
    			record.setBalance(scanner.nextDouble());
    			
    			System.out.printf("%-10d%-12s%-12s%-10.2f\n", record.getAccount(), record.getFirstName(), record.getLastName(), record.getBalance());
    		}
    	}catch(NoSuchElementException noSuchElementException) {
    		System.err.println("File improperly formed");
    		scanner.close();
    		System.exit(1);
    	}catch(IllegalStateException illegalStateException) {
    		System.err.println("Error reading from file");
    		System.exit(1);
    	}
    }
    
    public void closeFile() {
    	if(scanner != null) {
    		scanner.close();
    	}
    }
}
