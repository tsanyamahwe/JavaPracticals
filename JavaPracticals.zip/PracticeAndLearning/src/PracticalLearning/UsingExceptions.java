package PracticalLearning;

public class UsingExceptions {
    public static void throwsException() throws Exception{
    	try {
    		System.out.println("Method throws Exception");
    		throw new Exception();
    	}catch(Exception e) {
    		System.err.println("Exception handled in throwsException");
    		throw e;
    	}
    	finally {
    		System.err.println("Finally executed in throwsException");
    	}
    }
    
    public static void doesNotThrowException() {
    	try {
    		System.out.println("Method doesNotThrowException");
    	}catch(Exception e) {
    		System.err.println(e);
    	}
    	finally {
    		System.err.println("Finaly executed in doesNotThrowException");
    	}
    	System.out.println("End of the method doesNotThrowExceptions");
    }
    
    public static void main (String [] args) {
    	try {
    		throwsException();
    	}catch (Exception e) {
    		System.err.println("Exception handled in main");
    	}
    	doesNotThrowException();
    }
}
