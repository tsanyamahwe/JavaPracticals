package PracticalLearning;

public class StringsPlay {
   public static void main (String [] args) {
	   String s1 = new String("hello and how are you?");
	   String s2 = "goodbye";
	   String s3 = "Happy Birthday";
	   String s4 = "happy birthday";
	  
	   System.out.printf("s1: %s\ns2: %s\ns3: %s\ns4: %s\n", s1, s2, s3,s4);
	   
	   System.out.printf("\nLength of s1: %s", s1.length());
	   
	   System.out.print("\nThe reversed string: ");
	   for(int count = s1.length()-1; count >= 0; count--) {
		   System.out.printf("%s", s1.charAt(count));
	   }
	   
	   char[] charArray = new char[15];
	   s1.getChars(0, 15, charArray, 0);
	   System.out.print("\nThe Character array is: ");
	   for(char character: charArray) {
		   System.out.print(character);
	   }
	   System.out.println();
	   
	   if(s1.equals("hello")) { //test for equality; this is true
		   System.out.println("\ns1 equals \"hello\"");
	   }else {
		   System.out.println("s1 not equal \"hello\"");
	   }
	   
	   if(s1 == "hello") { //test for equality, this is false
		   System.out.println("s1 is the same as \"hello\"");
	   }else {
		   System.out.println("s1 is the not the same as \"hello\"");
	   }
	   
	   if(s3.equalsIgnoreCase(s4)){
		   System.out.printf("%s equals %s with cases ignored\n", s3, s4);
	   }else {
		   System.out.println("s3 does not eqal s4");
	   }
	   
	   System.out.printf("\ns1.compareTo(s2) is %d\n", s1.compareTo(s2));
	   System.out.printf("s2.compareTo(s1) is %d\n", s2.compareTo(s1));
	   System.out.printf("s1.compareTo(s1) is %d\n", s1.compareTo(s1));
	   System.out.printf("s3.compareTo(s4) is %d\n", s3.compareTo(s4));
	   System.out.printf("s4.compareTo(s3) is %d\n", s4.compareTo(s3));
	   
	   if(s3.regionMatches(0, s4, 0, 5)) {
		   System.out.println("\nFirst 5 characters of s3 and s4 match");
	   }else {
		   System.out.println("\nFirst 5 characters of s3 and s4 do not match");
	   }
	   
	   if(s3.regionMatches(true, 0, s4, 0, 5)) {
		   System.out.println("\nFirst 5 characters of s3 and s4 match with case ignored");
	   }else {
		   System.out.println("\nFirst 5 characters of s3 and s4 do not match");
	   }
   }
}
