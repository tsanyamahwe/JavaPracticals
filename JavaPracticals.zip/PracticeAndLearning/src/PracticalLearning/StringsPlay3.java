package PracticalLearning;

public class StringsPlay3 {
  public static void main(String []args) {
	  String letters = "abcdefghijklmabcdefghijklm";
	  String s1 = "happy ";
	  String s2 = "BIRTHDAY";
	  String s3 = " spaces ";
	  
	  System.out.printf("Substring from index 20 to the end is \"%s\"\n", letters.substring(20));
	  System.out.printf("Substring from index 3 up to but not including 6 is \"%s\"\n", letters.substring(3, 6));
	  
	  System.out.printf("\ns1 = %s\ns2 = %s\ns3 = %s\n", s1, s2, s3);
	  System.out.printf("\nResult of s1.concat(s2) is: %s\n", s1.concat(s2));
	  System.out.printf("s1 after concatenation is: %s\n", s1);
	  
	  System.out.printf("\nReplace 'p' with 'P' in s1: %s\n", s1.replace('p', 'P'));
	  System.out.printf("s1.toUpperCase() = %s\n", s1.toUpperCase());
	  System.out.printf("s2.toLowerCase() = %s\n", s2.toLowerCase());
	  System.out.printf("s3 after trim = \"%s\"\n\n", s3.trim());
	  
	  char[]charArray = s1.toCharArray();
	  System.out.print("s1 as a character array is: ");
	  
	  for(char array: charArray) {
		  System.out.print(array);
	  }
	  
	 System.out.print("\nThe reverse for string s2 is: ");
	 for(int count = s2.length()-1; count >= 0; count-- ) {
		 System.out.printf("%s", s2.charAt(count));
	 }
	 
	 char[] charArrays = {'a','b','c','d','e','f'};
	  boolean booleanValue = true;
	  char characterValue = 'Z';
	  int integerValue = 7;
	  long longValue = 10000000000L;
	  float floatValue = 2.5f;
	  double doubleValue = 33.333;
	  Object objectRef = "hello";
	  
	  System.out.printf("\n\nchar array = %s\n", String.valueOf(charArrays));
	  System.out.printf("part of char array = %s\n", String.valueOf(charArrays, 3, 3));
	  System.out.printf("boolean = %s\n", String.valueOf(booleanValue));
	  System.out.printf("char = %s\n", String.valueOf(characterValue));
	  System.out.printf("integer = %s\n", String.valueOf(integerValue));
	  System.out.printf("long = %s\n", String.valueOf(longValue));
	  System.out.printf("float = %s\n", String.valueOf(floatValue));
	  System.out.printf("double = %s\n", String.valueOf(doubleValue));
	  System.out.printf("Object = %s", String.valueOf(objectRef));
  }
}
