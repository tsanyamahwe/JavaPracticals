package PracticalLearning;

public class StringBuilders {
    public static void main(String [] args) {
    	StringBuilder buffer1 = new StringBuilder();
    	StringBuilder buffer2 = new StringBuilder(10);
    	StringBuilder buffer3 = new StringBuilder("hello");
    	StringBuilder buffers = new StringBuilder("Hello there, how are you?");
    	
    	Object objectRef = "hello";
    	String string = "goodbye";
    	char[] charArray = {'a','b','c','d','e','f'};
    	boolean booleanValue = true;
    	char characterValue = 'Z';
    	int integerValue = 7;
    	long longValue = 10000000000L;
    	float floatValue = 2.5f;
    	double doubleValue = 33.333;
    	
    	System.out.printf("buffer1 = \"%s\", buffer2 = \"%s\", buffer3 = \"%s\"\n", buffer1, buffer2, buffer3);
    	System.out.printf("\nbuffer = %s\nlength = %d\ncapacity = %d\n", buffers.toString(), buffers.length(), buffers.capacity());
    	
    	buffers.ensureCapacity(75);
    	System.out.printf("buffer new capacity: %d", buffers.capacity());
    	
    	buffers.setLength(10);
    	System.out.printf("\nNew length is: %d\nNew buffer string is: %s\n\n", buffers.length(), buffers.toString());
    	System.out.printf("Character at 0: %s\nCharacter at 4: %s\n", buffers.charAt(0), buffers.charAt(4));
    	
    	char[] charArrays = new char[buffers.length()];
    	buffers.getChars(0, buffers.length(), charArrays, 0);
    	System.out.print("Characters are: ");
    	for(char characters: charArrays) {
    		System.out.print(characters);
    	}
    	
    	buffers.setCharAt(0, 'T');
    	buffers.setCharAt(6, 'H');
    	System.out.printf("\nNew buffer: %s\n", buffers.toString());
    	buffers.reverse();
    	System.out.printf("\nReversed buffer is: %s\n", buffers.toString());
    	
    	StringBuilder lastbuffer = new StringBuilder("last buffer");
    	StringBuilder buffer = new StringBuilder();
    	buffer.append(objectRef);
    	buffer.append("\n");
    	buffer.append(string);
    	buffer.append("\n");
    	buffer.append(charArray);
    	buffer.append("\n");
    	buffer.append(characterValue);
    	buffer.append("\n");
    	buffer.append(booleanValue);
    	buffer.append("\n");
    	buffer.append(integerValue);
    	buffer.append("\n");
    	buffer.append(longValue);
    	buffer.append("\n");
    	buffer.append(floatValue);
    	buffer.append("\n");
    	buffer.append(doubleValue);
    	buffer.append("\n");
    	buffer.append(lastbuffer);
    	System.out.printf("buffer contains: %s", buffer.toString());
    	
    	buffer.insert(0, objectRef);
    	buffer.insert(0, " ");
    	buffer.insert(0, booleanValue);
    	buffer.insert(0, " ");
    	buffer.insert(0, charArray);
    	buffer.insert(0, " ");
    	buffer.insert(0, characterValue);
    	buffer.insert(0, " ");
    	buffer.insert(0, integerValue);
    	buffer.insert(0, " ");
    	buffer.insert(0, string);
    	buffer.insert(0, " ");
    	buffer.insert(0, longValue);
    	buffer.insert(0, " ");
    	buffer.insert(0, floatValue);
    	buffer.insert(0, " ");
    	buffer.insert(0, doubleValue);
    	
    	System.out.printf("\nbuffer after inserts: %s\n\n", buffer.toString());
    	
    	buffer.deleteCharAt(10);
    	buffer.delete(2, 6);
    	System.out.printf("\nbuffer after deleting: %s", buffer.toString());
    }
}
