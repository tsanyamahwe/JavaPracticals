package PracticalLearning;
import java.util.*;

public class HandlingExceptions {
    public static int quotient(int numerator, int denominator) throws ArithmeticException {
    	return numerator/denominator;
    }
    
    public static void main (String [] args) {
    	Scanner scanner = new Scanner(System.in);
    	boolean continueLoop = true;
    	do {
    		try {
    			System.out.println("Enter an Integer for numerator:");
    			int numerator = scanner.nextInt();
    			System.out.println("Enter an Integer for denominator:");
    			int denominator = scanner.nextInt();
    			
    			int result = quotient(numerator, denominator);
    			
    			System.out.printf("%S: %d/%d = %d", "Result of", numerator, denominator, result);
    			continueLoop = false;
    		}catch(InputMismatchException inputMismatchException){
    			System.err.printf("\n%s: %s\n", "Exception", inputMismatchException);
    			scanner.nextLine();
    			System.out.println("You must enter Integers, please try again\n");
    			
    		}catch(ArithmeticException arithmeticException) {
    			System.err.printf("\n%s: %s\n", "Exception", arithmeticException);
    			System.out.println("Zero is not a valid denominator. Please try again\n");
    		}
    	}while(continueLoop);
    }
}
