package PracticalLearning;
import java.util.*;

public class TokenStrings {
    public static void main(String [] args) {
    	Scanner scanner = new Scanner(System.in);
    	System.out.println("Enter a sentence and press \"Enter\":");
    	String sentence = scanner.nextLine();
    	
    	String[] tokens = sentence.split(" ");
    	System.out.printf("Number of elements: %d\n", tokens.length);
    	System.out.print("The tokens are:\n");
    	for(String token: tokens) {
    		System.out.println(token);
    	}
    }
}
