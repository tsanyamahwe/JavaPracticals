import java.util.*;

public class Craps {
  public static final Random randomNumbers = new Random();
  
  private enum Status {Continue, Won, Lost};
  
  private static final int SNAKE_EYES = 2;
  private static final int TREY = 3; 
  private static final int SEVEN = 7;
  private static final int YO_LEVEN = 11;
  private static final int BOX_CARS = 12;
  
  public static int rollDice() {
	  int die1 = 1 + randomNumbers.nextInt(6);
	  int die2 = 1 + randomNumbers.nextInt(6);
	  int sum = die1 + die2;
	  System.out.printf("Player rolled %d + %d = %d\n", die1, die2, sum);
	  return sum;
  }
  
  public static void playCraps() {
	  int myPoint = 0;
	  Status gameStatus;
	  int sumOfDice = rollDice();
	  
	  switch(sumOfDice) {
	    case SEVEN:
	    case YO_LEVEN:
	    	gameStatus = Status.Won;
	    	break;
	    case SNAKE_EYES:
	    case TREY:
	    case BOX_CARS:
	    	gameStatus = Status.Lost;
	    default:
	    	gameStatus = Status.Continue;
	    	myPoint = sumOfDice;
	    	System.out.printf("Point is %d\n", myPoint);
	  }
	  
	  while (gameStatus == Status.Continue) {
		  sumOfDice = rollDice();
		  if (sumOfDice == myPoint) {
			  gameStatus = Status.Won;
		  }else if (sumOfDice == SEVEN) {
				  gameStatus = Status.Lost;
		  }
	  }
	  if (gameStatus == Status.Won) {
		  System.out.println("\nPlayer *WINS!*");
	  }else {
		  System.out.println("\nPlayer *LOST!*");
	  }	  
  }
  
  public static void main (String [] args) {
	  playCraps();
  }
}
