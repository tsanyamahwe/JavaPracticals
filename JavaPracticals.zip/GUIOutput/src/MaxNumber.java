import java.util.*;

public class MaxNumber {
	
	public void readNumbers() {
		Scanner scanner = new Scanner (System.in);
		
		System.out.println("Enter the 3 numbers to be compared!");
		double number1 = scanner.nextDouble();
		double number2 = scanner.nextDouble();
		double number3 = scanner.nextDouble();
		
		double result = maximum(number1, number2, number3);
		
		System.out.printf("The maximum value is %.2f", result);
	}
	
	public static double maximum(double x, double y, double z) {
		
		return Math.max(x, Math.max(y, z) );
	}
	
	public void diceRolling() {
		Random randonNumber = new Random();
		int face;
		
		for (int k = 1; k <= 20; k++) {
			face = 1 + randonNumber.nextInt(6);
			System.out.printf("%d ", face);
			
			if (k % 5 == 0) {
				System.out.println();
			}
		}
	}
	
	public void diceRollingCasino() {
		Random randomValue = new Random();
		int frequency1 = 0, frequency2 = 0, frequency3 = 0, frequency4 = 0, frequency5 = 0, frequency6 = 0;
		int face;
		
		for (int counter = 1; counter <= 6000000; counter++ ) {
			face = 1 + randomValue.nextInt(6);
			switch(face) {
			case 1:++frequency1;
			       break;
			case 2:++frequency2;
		           break;
			case 3:++frequency3;
		           break;
			case 4:++frequency4;
		          break;
			case 5:++frequency5;
		          break;
			case 6:++frequency6;
		          break;
			}
		}
		System.out.println("Face\tFrequency");
		System.out.printf("1\t%d\n2\t%d\n3\t%d\n4\t%d\n5\t%d\n6\t%d", frequency1, frequency2, frequency3, frequency4, frequency5, frequency6);
	}
	public static void main (String [] args) {
		MaxNumber number = new MaxNumber();
		//number.readNumbers();
		//number.diceRolling();
		number.diceRollingCasino();
	}
}
