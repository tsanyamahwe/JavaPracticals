import java.util.*;
import java.lang.*;

public class FirstArray {
	private static final int ARRAY_LENGTH = 10; //array length
	private static int [] array = new int[ARRAY_LENGTH]; //array declaration
	private static int sum = 0;
	   
	public static void arrayInitialiser() {  //array value assigner
	  for (int k = 0; k < array.length; k ++) {
		  array [k] = 2 + 2 * k;
	  }
	  //array value printing
	  System.out.printf("%s%8s\n", "Index", "Value");
	  for (int k = 0; k < array.length; k++) {
		  System.out.printf("%5d%8d\n", k, array[k]);
	  }
	}
	
	public static void arraySum() {
		for (int k = 0; k < array.length; k++) {
			sum += array[k];
		}
		System.out.printf("\nThe sum of the array elements is %d", sum);
	}
	
	public static void gradingScoresArray() {
	      int [] array = new int[] {0, 0, 0, 0, 0, 0, 1, 2, 4, 2, 1};
	      
	      System.out.println("Grading Distribution");
	      
	      for (int counter = 0; counter < array.length; counter++) {
	    	  if (counter == 10) {
	    		  System.out.printf("%5d:", 100);
	    	  }else {
	    		  System.out.printf("%02d-%02d:", counter * 10, counter * 10 + 9);
	    	  }
	    	  for (int stars = 0; stars < array[counter]; stars++) {
	    		  System.out.print("*");
	    	  }
	    	  System.out.println();
	      }
	}
	
	public static void rollDiceArray() {
		Random randomNumbers = new Random();
		int [] frequency = new int[7];
		
		for (int rolldice = 1; rolldice <= 6000000; rolldice++) 
			++frequency[1 + randomNumbers.nextInt(6)];
			
			System.out.printf("%s%10s\n", "Face","Frequency");
			
		for (int face = 1; face < frequency.length; face++) 
		   System.out.printf("%2d%10d\n", face, frequency[face]);
	}
	
	public static void studentPoll() {
		int [] responses = new int [] {1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 3, 4, 5, 4, 3, 2, 1, 2, 3, 4};
		int [] frequency = new int [6];
		
		for (int answers = 0; answers < responses.length; answers++) {
			try {
				++frequency[responses[answers]];
			}
			catch(ArrayIndexOutOfBoundsException e) {
				System.out.println(e);
				System.out.printf("responses[%d] = %d\n", answers, responses[answers]);
			}
		}
		System.out.printf("%s%10s\n", "Rating", "Frequency");
		
		for (int poll = 1; poll < frequency.length; poll++) {
			System.out.printf("%3d%10d\n", poll, frequency[poll]);
		}
	}
	public static void enhancedForTest() {
		int [] array = {65, 71, 70, 90, 93, 95, 92, 88, 81, 73};
		int total = 0;
		
		for (int counter : array) {
			total += counter;
		}
		System.out.printf("The total mark is :%d", total);
	}
	
	public static void modifyArray() {
		int [] array = {65, 71, 70, 90, 93, 95, 92, 88, 81, 73};
		
		System.out.println("Effects of modifying an array: Original values are:");
		
		for(int counter: array) {
			System.out.printf(" %d", counter);
		}
		
		modifyArrays(array);
		System.out.println("\nThe modified array values are:");
		
		for (int value: array) {
			System.out.printf(" %d", value);
		}
		System.out.printf("\n\nEffects of passing array element value:\n" + "array [3] before modufyElement is: %d\n", array[3]);
		
		modifyElement(array[3]);
		System.out.printf("array [3] after modifyElement: %d\n", array[3]);
	}
	
	public static void modifyArrays(int [] arrays2) {
		for (int counter = 0; counter < arrays2.length; counter++) {
			arrays2[counter] *= 2;
		}
	}
	
	public static void modifyElement(int element) {
		element *= 2;
		System.out.printf("The value of modified element is %d ", element);
	}
	
  public static void main (String [] args) {
	  //arrayInitialiser();
	  //arraySum();
	  //gradingScoresArray();
	  //rollDiceArray();
	  //studentPoll();
	  //enhancedForTest();
	  modifyArray();
  }
}
