import javax.swing.*;

public class CompoundInterest {
	
	public void doubleCompountInterest() {
		double amount, principal = 1000.00, rate = 0.05;
		  
		  String message = String.format("%s%20s\n","Year","Amount of year");
		  String message1 = "", capture = "";
		  for (int year = 1; year <= 10; year ++) {
			  amount = principal*Math.pow(1.0 + rate, year);
			  message1 = String.format("%3d%25.2f\n",year,amount);
			  capture = capture + message1;
		  } 
		  JOptionPane.showMessageDialog(null, message + capture);
	}
	
	public void integerCompountInterest() {
		int amount, principal = 1000, rate = 1;
		String message = String.format("%s%20s\n","Year", "Amount of year");
		String message1 = "", capture = "";
		for (int year = 1; year <= 10; year++) {
			amount = (int) (principal*Math.pow(1 + rate, year));
			
		}
	}
  public static void main (String [] args) {
	  
  } 
}
