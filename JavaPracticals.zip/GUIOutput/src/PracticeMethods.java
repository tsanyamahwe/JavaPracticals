import javax.swing.*;
import java.util.*;

public class PracticeMethods {
  public static void Minimum3() {
	  double number1 = 0, number2 = 0, number3 = 0;
	  double smallest = Double.MAX_VALUE;
	  
	  String value1 = JOptionPane.showInputDialog("Enter the 1st floating number:");
	  number1 = Double.parseDouble(value1);
	  String value2 = JOptionPane.showInputDialog("Enter the 2nd floating number:");
	  number2 = Double.parseDouble(value2);
	  String value3 = JOptionPane.showInputDialog("Enter the 3rd floating number:");
	  number3 = Double.parseDouble(value3);
	  
	  smallest = Math.min(number1, Math.min(number2, number3));
	  
	  String message = String.format("The smallest floating number on the provided list is %.2f", smallest);
	  JOptionPane.showMessageDialog(null, message);
  }
  
  public static boolean isPerfectNumber(int number) {
      int sum = 0;
      
      for (int i = 1; i <= number / 2; i++) {
          if (number % i == 0) {
              sum += i;
          }//end if
          
      }//end for
      if (sum == number) {
          System.out.printf("%d is a perfect number.\n", number);
      }
      return sum == number;
  }//end method
  
  public static void findPerfectNumber() {
	  for (int k = 1; k <= 10000; k++) {
		  isPerfectNumber(k);
	  }
  }
  
  public static boolean isPrime(int n) {
	 if (n <= 1) {
		 return false;
	 }
	 for (int i = 2; i <= Math.sqrt(n); i++) {
		 if(n % i == 0) {
			 return false;
		 }
	 }
	 return true;
  }
  
  public static void findPrimeNumbers() {
	  for (int k = 2; k < 20; k++) {
		  if (isPrime(k))
		  System.out.printf("%d is prime number\n", k);
		  }
	  }
  
  public static void main (String [] args) {
	  //Minimum3();
	  findPerfectNumber();
	  //findPrimeNumbers();
	  //isPerfect(5);
  }
}
