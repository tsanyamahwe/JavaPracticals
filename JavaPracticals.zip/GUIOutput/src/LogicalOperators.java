import javax.swing.JOptionPane;

public class LogicalOperators {
	private int intNumber;
	private int smallest = Integer.MAX_VALUE;
	
	public void displayMessage() {
		String message = String.format("The smallest integer in the given list is: %d", smallest);
		JOptionPane.showMessageDialog(null, message);
	}
	
	public void findSmallestInt() {
		String integer = JOptionPane.showInputDialog("Enter the next Integer OR 0 to exit:");
		intNumber = Integer.parseInt(integer);
		
		while (intNumber != 0) {
			if (intNumber < smallest) {
				smallest = intNumber;
			}
			integer = JOptionPane.showInputDialog("Enter the next Integer OR 0 to exit:");
			intNumber = Integer.parseInt(integer);
		}
		if (smallest != Integer.MAX_VALUE) {
			displayMessage();
		}else {
			JOptionPane.showMessageDialog(null, "No integers were entered!");
		}
	}
  public static void main (String [] args) {
	  LogicalOperators lo = new LogicalOperators();
	  lo.findSmallestInt();
  }
}
