import javax.swing.JOptionPane;

public class BankAccount{
	private double balance;
	
	public BankAccount(double bankBalance) {
		balance = bankBalance;
	}
	
	public void Credit (double amountdeposited) {
		balance = balance + amountdeposited;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void displayMesssage () {
		System.out.printf("Balance:", getBalance());
	}
	
	public static void main (String [] args) {
		BankAccount account1 = new BankAccount(50.00);
		BankAccount account2 = new BankAccount(-140.00);
		double deposit;
		
		String value = JOptionPane.showInputDialog("Deposit for Savings Account:");
		deposit = Double.parseDouble(value);
		account1.Credit(deposit);
		String message = String.format("Savings Account Balance: $%.2f\n", account1.getBalance());
		//JOptionPane.showMessageDialog(null, account1.getBalance());
				
		String value2 =JOptionPane.showInputDialog("Deposit for Current Account:");
		deposit = Double.parseDouble(value2);
		account2.Credit(deposit);
		String message2 = String.format("Current Account Balance: $%.2f", account2.getBalance());
		JOptionPane.showMessageDialog(null, message + message2);
		//JOptionPane.showMessageDialog(null, "Welcome to Java");
	}
}