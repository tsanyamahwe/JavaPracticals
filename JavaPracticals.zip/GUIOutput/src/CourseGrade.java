import javax.swing.*;

public class CourseGrade {
  private String courseName;
  
  public CourseGrade(String course) {
	  courseName = course;
  }
  
  public void setCourseGrade(String course) {
	  courseName = course;
  }
  
  public String getCourseGrade() {
	  return courseName;
  }
  
  public void displayMessage () {
	  System.out.printf("Welcome to %s", getCourseGrade());
  }
  
  public void determineCourseAverage() {
	  int mark, total = 0, counter = 0, average;
	  String value, capture ="", message2="";
	  
	  value = JOptionPane.showInputDialog("Enter the next mark OR -1 to exit:");
	  mark = Integer.parseInt(value);
	  //capture = capture + value +",";
	  while (mark != -1) {
		  total = total + mark;
		  counter = counter + 1;
		  value = JOptionPane.showInputDialog("Enter the next mark OR -1 to exit");
		  mark = Integer.parseInt(value);
		  //capture = capture + value +",";
		  //String ms = String.format(capture);
		 // message2 = String.format("Marks entered are: %s\n", ms);
	  }
	  
	  if (counter != 0) {
		  average = total/counter;
		  String message = String.format("Total mark for %d students is: %d\n", counter, total);
		  String message1 = String.format("Class average is: %d", average);
		  JOptionPane.showMessageDialog(null, message2 + message + message1);
	  }
  }
   public static void main (String [] args) {
	   CourseGrade courseGrade = new CourseGrade ("CS01: Introduction to Java Programming!");
	   courseGrade.displayMessage();
	   courseGrade.determineCourseAverage();
   }
}
