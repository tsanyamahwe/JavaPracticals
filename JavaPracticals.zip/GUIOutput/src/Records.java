import javax.swing.*;

public class Records {
	private int score;
	
	public Records() {}
	public void setRecord(int value) {score = value;}
	public int getRecord() {return score;}
	public void displayMessage() {System.out.printf("", getRecord());}
	public void determineRecordResult() {
		int pass = 0, fail =0, countStudent = 0, result;
		
		while (countStudent < 10) {
			String number = JOptionPane.showInputDialog("Enter result (Pass = 1, Fail = 2):");
			result = Integer.parseInt(number);
			if (result == 1) {
				pass++;
			} else {
				fail++;
			}
			countStudent++;
		}
		String message1 = String.format("Passes were %d, Fails were %d\n", pass, fail);
		String message2;
		if (pass >= 8) {
			message2 = String.format("The instructor to get a bonus");
		} else {
			message2 = String.format("No bonus for the instructor");
		}
		JOptionPane.showMessageDialog(null, message1 + message2);
	}
	
	public static void main (String [] args) {
		Records records = new Records();
		records.determineRecordResult();
	}
}
