import java.awt.*;
import javax.swing.*;

import javax.swing.*;

public class Shapes extends JPanel{
   private int choice;
   
   public void paintComponent(Graphics g) {
	  super.paintComponent(g);
	  //draw a face
	  g.setColor(Color.YELLOW);
	  g.fillOval(10, 10, 200, 200);
	  
	  //draw the eyes
	  g.setColor(Color.BLACK);
	  g.fillOval(55, 65, 30, 30);
	  g.fillOval(135, 65, 30, 30);
	  
	  //draw the mouth
	  g.fillOval(50, 110, 120, 60);
	  
	  //mouth touch ups
	  g.setColor(Color.YELLOW);
	  g.fillOval(50, 110, 120, 30);
	  g.fillOval(50, 120, 120, 40);
   }
   
   public static void main (String [] args) {
	 Shapes shape  = new Shapes();
	 JFrame application = new JFrame();
	 application.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 application.add(shape);
	 application.setSize(300, 300);
	 application.setVisible(true);
   }
}
