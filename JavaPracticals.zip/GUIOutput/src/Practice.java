import java.util.*;

public class Practice 
{
	private int intNumber;
	private int smallest = Integer.MAX_VALUE;
	
	public void displayMessage() 
	{
		System.out.printf("The smallest integer is %d", smallest);
	}
	
	public void findSmallestInteger()
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Enter a number OR 0 to exit");
		intNumber = input.nextInt();
		
		while (intNumber != 0)
		{
			if (intNumber < smallest)
			{
				smallest = intNumber;
			}
			
			System.out.println("Enter a number OR 0 to exit");
			intNumber = input.nextInt();
		}
		
		if (smallest != Integer.MAX_VALUE)
		{
			displayMessage();
		}
		else
		{
			System.out.println();
		}
	}
	 public void sumOfOddNumbers() {
		 int sum=0, k;
		 Scanner scanner = new Scanner(System.in);
		 for (k = 1; k <= 15; k++) {
			 if (k % 2 == 1) {
				 sum += k;
			 }
		 }
		 System.out.printf("The sum of odd numbers from 1 to 15 is: %d", sum);
	 }
	
	 public static int Square(int intValue) {
		 System.out.printf("Called Square with INT argument gives: %d\n", intValue);
		 return intValue * intValue;
	 }
	 
	 public static double Square(double doubleValue) {
		 System.out.printf("Called Sqaure with Double argument gives: %.2f\n", doubleValue);
		 return doubleValue * doubleValue;
	 }
 public static void main (String [] args)
 {
	 Practice p = new Practice();
	 //p.findSmallestInteger();
	 //p.sumOfOddNumbers();
	 System.out.println("Enter an INTEGER as input:");
	 Scanner scanner = new Scanner(System.in);
	 int value = scanner.nextInt();
	 //Square (value);
	 System.out.printf("The square of the given INTEGER is: %d\n", Square(value));
	 System.out.println("Enter a DOUBLE as input:");
	 double value1 = scanner.nextDouble();
	 //Square (value1);
	 System.out.printf("The square of the given Double is: %.2f\n", Square(value1));
 }
}
