package FileStreaming;
import java.io.Serializable;

public class AccountRecordSerializable implements Serializable{
     private int account;
     private String firstName;
     private String lastName;
     private double balance;
     
     public AccountRecordSerializable() {
    	 this(0,"","",0.0);
     }
     
     public AccountRecordSerializable(int acc, String name, String surname, double bal) {
    	 setAccount(acc);
    	 setFirstName(name);
    	 setLastName(surname);
    	 setBalance(bal);
     }
     
     public void setAccount(int acc) {
    	 account = acc;
     }
     
     public int getAccount() {
    	 return account;
     }
     
     public void setFirstName(String name) {
    	 firstName = name;
     }
     
     public String getFirstName() {
    	 return firstName;
     }
     
     public void setLastName(String surname) {
    	 lastName = surname;
     }
     
     public String getLastName() {
    	 return lastName;
     }
     
     public void setBalance(double bal) {
    	 balance = bal;
     }
     
     public double getBalance() {
    	 return balance;
     }
     
     public String toString() {
    	 return String.format("%-10d %-12s %-12s %-10.2f", getAccount(), getFirstName(), getLastName(), getBalance());
     }
}
