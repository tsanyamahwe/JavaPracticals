package FileStreaming;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class CreateSequentialFile {
     private ObjectOutputStream output;
     
     public void openFile() {
    	 try {
    		 output = new ObjectOutputStream(new FileOutputStream("Customer.ser"));
    	 }catch(IOException ioException) {
    		 System.err.println("Error opening file");
    		 System.exit(1);
    	 }
     }
     
     public void addRecord() {
    	 AccountRecordSerializable record;
    	 int accountNumber = 0;
    	 String firstName;
    	 String lastName;
    	 double balance;
    	 
    	 Scanner scanner = new Scanner(System.in);
    	 
    	 System.out.printf("%s\n%s\n%s\n\n", 
    			 "Enter an end-of-file delimeter to signal end of file",
    			 "On UNIX/Linux/Mac OS X type <ctrl> d then press Enter",
    			 "On Windows type <ctrl> z then press Enter");
    	 
    	 System.out.printf("%s, %s\n", "Enter \"Account Number\", \"Name\", \"Surname\" and \"Balance\".", "?");
    	 
    	 while(scanner.hasNext()) {
    		 try {
    			 accountNumber = scanner.nextInt();
    			 firstName = scanner.next();
    			 lastName = scanner.next();
    			 balance = scanner.nextDouble();
    			 
    			 if(accountNumber > 0) {
    				 record = new AccountRecordSerializable(accountNumber, firstName, lastName, balance);
    				 output.writeObject(record);
    			 }else {
    				 System.out.println("Account number not real");
    			 }
    		 }catch(IOException ioException) {
    			 System.err.println("Error writing to file");
    			 return;
    		 }catch(NoSuchElementException noSuchElementException) {
    			 System.err.println("Invalid input. Please try again");
    			 scanner.nextLine();
    		 }
    	 }
    	 System.out.printf("%s, %s\n", "Enter \"Account Number\", \"Name\", \"Surname\" and \"Balance\".", "?");
     }
     
     public void closeFile() {
    	 try {
    		 if(output != null) {
    			 output.close();
    		 }
    	 }catch(IOException ioException) {
    		 System.err.println("Error closing file");
    		 System.exit(1);
    	 }
     }
}
