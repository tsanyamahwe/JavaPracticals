package FileStreaming;

public class ReadSequentialFileTesting {
    public static void main(String[]args) {
    	ReadSequentialFile application = new ReadSequentialFile();
    	application.openFile();
    	application.readFile();
    	application.closeFile();
    }
}
