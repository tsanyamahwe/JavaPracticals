package JavaCaseStudy;

public class Card
{
  private String face; // face of card ("Ace", "Deuce", ...)
  private String suit; // suit of card ("Hearts", "Diamonds", ...)
  
  //argument constructor initializes card's face and suit
  public Card(String cardFace, String cardSuit)
  {
	  face = cardFace;
	  suit = cardSuit;
  }
  // return string representation of card
  public String toString()
  {
	  return face + " of " + suit;
  }
}
