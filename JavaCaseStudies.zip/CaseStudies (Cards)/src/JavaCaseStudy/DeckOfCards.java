package JavaCaseStudy;
import java.util.*;

public class DeckOfCards
{
	private static final Random randomNumbers = new Random(); // random number generator
	
	private Card [] deck; // array of Cards objects
	private int currentCard; // index of next card
	private static final int NUMBER_OF_CARDS = 52; // number of cards in the deck
	
	public DeckOfCards()
	{
		String [] faces = {"Ace", "Deuce", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", "Jack",
				"Queen", "King"};
		String [] suit = {"Hearts", "Diamonds", "Clubs", "Spades"};
		
		deck = new Card[NUMBER_OF_CARDS]; // create array of card objects
		currentCard = 0; // set current card so first card dealt  is deck[0]
		
		for (int count = 0; count < deck.length; count++) 
		{
			deck [count] = new Card (faces[count % 13], suit[count / 13]);
		}
	}
	
	public void cardShuffle() // shuffling deck of Cards with one-pass algorithm
	{
		// after shuffling dealing should start at deck[0] again
		currentCard = 0; // re-initialize current Card
		
		for (int firstCard = 0; firstCard < deck.length; firstCard++) 
		{
			int secondCard = randomNumbers.nextInt(NUMBER_OF_CARDS); // select a randomNumber between 0 and 51
			
			// swapping current card with randomly selected card
			Card temp = deck[firstCard];
			deck[firstCard] = deck[secondCard];
			deck[secondCard] = temp;
		}
	} //end of shuffling
	
	public Card dealCard() // deal one card
	{
		if (currentCard < deck.length) //determines whether cards remain to be dealt
		{
			return deck[currentCard++]; // return current card in array
		} else 
		{
			return null; // to indicate ALL cards were dealt with
		}
	}
}
