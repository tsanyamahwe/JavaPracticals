package JavaCaseStudy;

public class DeckOfCardsTest
{
	public static void main (String [] args)
	{
		DeckOfCards myDeckOfCards = new DeckOfCards();
		myDeckOfCards.cardShuffle(); // shuffling cards
		
		for (int i =1; i <= 52; i++) // dealing OR playing the cards
		{
			System.out.printf("%-20s", myDeckOfCards.dealCard());
			if (i % 4 == 0)
			{
				System.out.println();
			}
		}
	}
}
