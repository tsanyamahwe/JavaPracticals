/**
 * 
 */
/**
 * 
 */
module CaseStudiesInterfacesAndAbstractClasses {
}