package CaseStudyInterfaces;

public interface Payable {
   double getPaymentAmount();
}
