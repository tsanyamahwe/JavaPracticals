package CaseStudyInterfaces;

public class Invoice implements Payable{
    private String partNumber;
    private String partDescription;
    private int quantity;
    private double pricePerItem;
    
    public Invoice(String part, String description, int itemquantity, double price) {
    	partNumber = part;
    	partDescription = description;
    	setQuantity (itemquantity);
    	setPricePerItem(price);
    }
    
    public void setQuantity(int itemquantity) {
    	if(itemquantity >= 0) {
    		quantity = itemquantity;
    	}else {
    		throw new IllegalArgumentException("Quantity of Items should be >=0");
    	}
    }
    
    public int getQuantity() {
    	return quantity;
    }
    
    public void setPricePerItem(double price) {
    	if(price >= 0) {
    		pricePerItem = price;
    	}else {
    		throw new IllegalArgumentException("Price should be >= 0");
    	}
    }
    
    public double getPricePerItem() {
    	return pricePerItem;
    }
    
    public void setPartNumber(String part) {
    	partNumber = part;
    }
    
    public String getPartNumber() {
    	return partNumber;
    }
    
    public void setPartDescription(String description) {
    	partDescription = description;
    }
    
    public String getPartDescription() {
    	return partDescription;
    }
    
    @Override
    public double getPaymentAmount() {
    	return getQuantity() * getPricePerItem();
    }
    
    @Override
    public String toString() {
    	return String.format("%S: \n%S: %S (%S)\n%S: %d\n%S: R%.2f\n", "Invoice", "Part Number", getPartNumber(), getPartDescription(), "Quantity", getQuantity(),
    			"Price per Item", getPricePerItem());
    }
}
