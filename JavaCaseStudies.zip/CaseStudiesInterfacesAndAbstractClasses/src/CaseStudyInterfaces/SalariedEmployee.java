package CaseStudyInterfaces;

public class SalariedEmployee extends Employee{
      private double weeklySalary;
      
      public SalariedEmployee(String first, String last, String ssNumber, double salary) {
    	  super(first, last, ssNumber);
    	  setWeeklySalary(salary);
      }
      
      public void setWeeklySalary(double salary) {
    	  if(salary >= 0) {
    		  weeklySalary = salary;
    	  }else {
    		  throw new IllegalArgumentException("Salary should be >= 0");
    	  }
      }
      
      public double getWeeklySalary() {
    	  return weeklySalary;
      }
      
      @Override
      public double getPaymentAmount() {
    	  return getWeeklySalary();
      }
      
      public String toString() {
    	  return String.format("%S: %s\n%S: %.2f", "Salaried Employee", super.toString(), "Salary", getPaymentAmount());
      }
}
