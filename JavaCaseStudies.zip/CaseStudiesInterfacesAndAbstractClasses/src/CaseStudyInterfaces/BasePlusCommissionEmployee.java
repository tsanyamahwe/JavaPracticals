package CaseStudyInterfaces;

public class BasePlusCommissionEmployee extends CommissionEmployee{
    private double baseSalary;
    
    public BasePlusCommissionEmployee(String first, String last, String ssNumber, double sales, double rate, double salary) {
    	super(first, last, ssNumber, sales, rate);
    	setBaseSalary(salary);
    }
    
    public void setBaseSalary(double salary) {
    	if(salary >= 0) {
    		baseSalary = salary;
    	}else {
    		throw new IllegalArgumentException("Salary should be >= 0");
    	}
    }
    
    public double getBaseSalary() {
    	return baseSalary;
    }
    @Override
    public double getPaymentAmount() {
    	return super.getPaymentAmount() + getBaseSalary();
    }
    @Override
    public String toString() {
    	return String.format("%s: %s\n%s: %.2f", "Base and Commission Employee", super.toString(), "Base Salary", getBaseSalary());
    }
}
