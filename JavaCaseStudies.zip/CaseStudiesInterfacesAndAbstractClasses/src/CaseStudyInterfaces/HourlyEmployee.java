package CaseStudyInterfaces;

public class HourlyEmployee extends Employee{
       private int hours;
       private double wage;
       
       public HourlyEmployee(String first, String last, String ssNumber, int hrs, double pay) {
    	   super(first, last, ssNumber);
    	   setHours(hrs);
    	   setWage(pay);
       }
       
       public void setHours(int hrs) {
    	   if((hrs >= 0) && (hrs <= 168)){
    		   hours = hrs;
    	   }else {
    		   throw new IllegalArgumentException("Hours should be >= 0");
    	   }
       }
       
       public int getHours() {
    	   return hours;
       }
       
       public void setWage(double pay) {
    	   if(pay >= 0.0) {
    		   wage = pay;
    	   }else {
    		   throw new IllegalArgumentException("Wage should be >= 0");
    	   }
       }
       
       public double getWage() {
    	   return wage;
       }
       
       @Override
       public double getPaymentAmount() {
    	   if(getHours() <= 40) {
    		   return getWage() * getHours();
    	   }else {
    		   return 40 * getWage() + ((getHours() - 40) * getWage() * 1.5);
    	   }
       }
       
       @Override
       public String toString() {
    	   return String.format("%s: %s\n%s: %.2f\n%s: %d", "Hourly Employee", super.toString(), "Wage is", getWage(), "Hours worked", getHours());
       }
}
