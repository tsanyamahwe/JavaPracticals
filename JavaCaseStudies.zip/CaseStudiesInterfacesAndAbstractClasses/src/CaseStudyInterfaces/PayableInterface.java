package CaseStudyInterfaces;

public class PayableInterface {
    public static void main (String [] args) {
    	Payable [] payableObjects = new Payable[6];
    	payableObjects [0] = new Invoice("2134", "seat", 2, 123.45);
    	payableObjects [1] = new Invoice("3124", "wheel", 3, 213.32);
    	payableObjects [2] = new SalariedEmployee("Salmon", "Brake", "111-111", 9645.17);
    	payableObjects [3] = new HourlyEmployee("Tracy", "Baic", "222-222", 42, 87.43);
    	payableObjects [4] = new CommissionEmployee("Lucy", "Trophie", "333-333", 16745.47, .4);
    	payableObjects [5] = new BasePlusCommissionEmployee("Daiton", "Prescot", "444-444", 12453.13, .2, 6436.55);
    	
    	System.out.println("Invoices and Employee processed polymorphically:\n");
    	
    	for(Payable currentPayable: payableObjects) {
    		System.out.printf("%s\n%s: %.2f\n\n", currentPayable.toString(), "Payment Due", currentPayable.getPaymentAmount());
    	}
    }
}
