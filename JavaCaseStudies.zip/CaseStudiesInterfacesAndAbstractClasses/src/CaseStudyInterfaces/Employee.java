package CaseStudyInterfaces;

public abstract class Employee implements Payable{
     private String firstName;
     private String lastName;
     private String socialSecurityNumber;
     
     public Employee(String name, String surname, String ssNumber) {
    	 firstName = name;
    	 lastName = surname;
    	 socialSecurityNumber = ssNumber;
     }
     
     public void setFirstName(String name) {
    	 firstName = name;
     }
     
     public String getFirstName() {
    	 return firstName;
     }
     
     public void setLastName(String surname) {
    	 lastName = surname;
     }
     
     public String getLastName() {
    	 return lastName;
     }
     
     public void setSSNumber(String ssNumber) {
    	 socialSecurityNumber = ssNumber;
     }
     
     public String getSSNumber() {
    	 return socialSecurityNumber;
     }
     
     @Override
     public String toString() {
    	 return String.format("%S: %s %s\n%S: %s\n", "Employee Name", getFirstName(), getLastName(), "Social Security Number", getSSNumber());
     }
}
