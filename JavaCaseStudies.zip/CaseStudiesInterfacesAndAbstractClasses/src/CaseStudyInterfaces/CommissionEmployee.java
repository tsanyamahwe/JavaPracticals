package CaseStudyInterfaces;

public class CommissionEmployee extends Employee{
     private double grossSale;
     private double commissionRate;
     
     public CommissionEmployee(String first, String last, String ssNumber, double sales, double rate) {
    	 super(first, last, ssNumber);
    	 setGrossSales(sales);
    	 setCommissionRate(rate);
     }
     
     public void setGrossSales(double sales) {
    	 if(sales >= 0) {
    		 grossSale = sales;
    	 }else {
    		 throw new IllegalArgumentException("Sales should be >= 0");
    	 }
     }
     
     public double getGrossSales() {
    	 return grossSale;
     }
     
     public void setCommissionRate(double rate) {
    	 if (0.0 <= rate && rate <= 1.0) {
    		 commissionRate = rate;
    	 }else {
    		 throw new IllegalArgumentException("Rate should be >= 0");
    	 }
     }
     
     public double getCommissionRate() {
    	 return commissionRate;
     }
     @Override
     public double getPaymentAmount() {
    	 return getGrossSales() * getCommissionRate();
     }
     @Override
     public String toString() {
    	 return String.format("%s: %s\n%s: %.2f\n%s: %.2f", "Commission Employee", super.toString(), "Gross Sales", getGrossSales(), "Commission Rate", getCommissionRate());
     }
}
