package atmCaseStudy;

public class Deposit extends Transaction{
    private double amount;
    private Keypad keypad;
    private DepositSlot depositSlot;
    private static final int CANCELED = 0;
    
    public Deposit(int account, Screen screen, BankDatabase database, Keypad keyPad, DepositSlot moneySlot) {
    	super(account, screen, database);
    	keypad = keyPad;
    	depositSlot = moneySlot;
    }
    @Override
    public void execute() {
    	BankDatabase bankDatabase = getBankDatabase();
    	Screen screen = getScreen();
    	
    	amount = promptForDepositAmount();
    	if(amount != CANCELED) {
    		screen.displayMessage("\nPlease insert a deposit envelope containing: ");
    		screen.displayAmountInRands(amount);
    		screen.displayMessageLine(".");
    		
    		boolean envelopReceived = depositSlot.isEnvelopeReceived();
    		if(envelopReceived) {
    			screen.displayMessageLine("\nYour envelop has been received.\nNOTE: The money just deposited will not be available until verification is completed");
    			bankDatabase.credit(getAccountNumber(), amount);
    		}else {
    			screen.displayMessageLine("\nYou did not insert an envelope, so the ATM has cancelled your transaction");
    		}
    	}else {
    		screen.displayMessageLine("Cancelling transactions....");
    	}
    }
    
    private double promptForDepositAmount() {
    	Screen screen = getScreen();
    	screen.displayMessageLine("\nPlease enter the amount of money is CENTS (or 0 to cancel:)");
    	int input = keypad.getInput();
    	if(input == CANCELED) {
    		return CANCELED;
    	}else {
    		return (double) input / 100;
    	}
    }
}
