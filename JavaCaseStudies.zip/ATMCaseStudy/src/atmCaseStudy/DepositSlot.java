package atmCaseStudy;

public class DepositSlot { //represents a deposit slot of the ATM
    public boolean isEnvelopeReceived() { //indicates whether the envelope was received
    	return true; //deposit envelope was received
    }
}
