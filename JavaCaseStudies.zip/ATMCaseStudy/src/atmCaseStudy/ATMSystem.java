package atmCaseStudy;

public class ATMSystem {
   public static void main(String [] args) {
	   ATM atm = new ATM();
	   atm.run();
   }
}
