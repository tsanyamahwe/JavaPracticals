package atmCaseStudy;
//represents an automated teller machine
public class ATM {
   private boolean userAuthenticated; //authentication
   private Screen screen; //ATM's screen
   private Keypad keypad; //ATM's keypad
   private BankDatabase bankDatabase; //account information database
   private CashDispenser cashDispenser; //ATM's cash dispenser
   private DepositSlot depositSlot; //ATM's deposit slot
   private int currentAccountNumber; //user's account number
   
   //constants corresponding to main menu
   private static final int BALANCE_INQUIRY = 1;
   private static final int WITHDRAWAL = 2;
   private static final int DEPOSIT = 3;
   private static final int EXIT = 4;
   
   //no argument ATM constructor initializes instance variables
   public ATM() {
	   userAuthenticated = false; //user not authenticated to start
	   screen = new Screen(); // create screen
	   keypad = new Keypad(); // create keypad
	   bankDatabase = new BankDatabase(); // new account info
	   cashDispenser = new CashDispenser(); // create cash dispenser
	   depositSlot = new DepositSlot(); //create deposit slot
	   currentAccountNumber = 0; //no current account number to start
   }
   //start an ATM
   public void run() {
	   while (true) { //welcome and authenticate user; perform transactions
		   while(!userAuthenticated) { //loop while user is not authenticated
			   screen.displayMessageLine("\nWelcome");
			   authenticateUser(); //authenticate the user
		   }
		   performTransactions(); //user is authenticated
		   userAuthenticated = false; //reset before the next ATM session
		   currentAccountNumber = 0; //reset before the next ATM session
		   screen.displayMessageLine("\nThank you! Good-bye!");
	   }
   }
   //attempts to authenticate a user against database
   private void authenticateUser() {
	   screen.displayMessage("\nPlease enter your account number: ");//prompt for account number
	   int accountNumber = keypad.getInput();//input account number
	   screen.displayMessage("\nEnter your pin: ");//prompt for pin
	   int pin = keypad.getInput();//input pin
	    
	   //set user authenticated to boolean value returned by database
	   userAuthenticated = bankDatabase.authenticateUser(accountNumber, pin);
	   if(userAuthenticated) { //check if authentication succeeded
		   currentAccountNumber = accountNumber;//save user's account
	   }else {
		   screen.displayMessageLine("Invalid account number OR pin. Please try again");
	   } 
   }
   //display the main menu and perform a transaction
   private void performTransactions() {
	   Transaction currentTransaction = null; //local variable to store transaction currently underway
	   boolean userExited = false; //user has not chosen exit
	   while(!userExited) {//loop while user has not chosen exit
		   int mainMenuSelection = displayMainMenu(); //show main menu and get user selection
		   switch(mainMenuSelection) {
		      case BALANCE_INQUIRY:
		      case WITHDRAWAL:   //a user to chose from the options for transaction
		      case DEPOSIT:
		    	  currentTransaction = createTransaction(mainMenuSelection);
		    	  currentTransaction.execute();
		    	  break;
		      case EXIT: //user chose to terminate session
		    	  screen.displayMessageLine("\nExiting the system....");
		    	  userExited = true;//this ATM session should end
		    	  break;
		      default: //user did not enter an integer from 1-4
		    	  screen.displayMessageLine("\nYou did not enter a valid selection. Try again");
		    	  break;
		   }
	   }
   }
   //displaying the main menu and return an input selection 
   private int displayMainMenu() {
	   screen.displayMessageLine("\nMain Menu:");
	   screen.displayMessageLine("1 - View My Balance");
	   screen.displayMessageLine("2 - Withdraw Cash");
	   screen.displayMessageLine("3 - Deposit Funds");
	   screen.displayMessageLine("4 - Exit");
	   screen.displayMessageLine("Enter a choice:");
	   return keypad.getInput();//returns user's selection
   }
   //return object of specified Transaction subclass
   private Transaction createTransaction(int type) {
	   Transaction temp = null;
	   switch(type) {
	      case BALANCE_INQUIRY://create a new balance inquiry
	    	temp = new BalanceInquiry(currentAccountNumber, screen, bankDatabase);
	    	break;
	      case WITHDRAWAL://create a withdrawal transaction
	    	temp = new Withdrawal(currentAccountNumber, screen, bankDatabase, keypad, cashDispenser);
	    	break;
	      case DEPOSIT://create a new deposit transaction
	    	temp = new Deposit(currentAccountNumber, screen, bankDatabase, keypad, depositSlot);
	    	break;
	   }
	   return temp;
   }
}
