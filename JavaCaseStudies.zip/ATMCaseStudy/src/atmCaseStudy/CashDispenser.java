package atmCaseStudy;

public class CashDispenser {
    private static final int INITIAL_COUNT = 500; // default initial value of bills/notes in the dispenser;
    private int count; //number of R20 bills/notes remaining
  
    public CashDispenser() {
    	count = INITIAL_COUNT; //initializing count to default
    }
    
    public void dispenseCash(int amount) { //simulating dispensing of specified amount of cash
    	int billsRequired = amount / 20;
    	count -= billsRequired;
    }
    
    public boolean isSufficientCashAvailable(int amount) {
    	int billsRequired = amount / 20;//number of R20 bills required
    	if(count >= billsRequired) {
    		return true;
    	}else {
    		return false;
    	}
    }
}
