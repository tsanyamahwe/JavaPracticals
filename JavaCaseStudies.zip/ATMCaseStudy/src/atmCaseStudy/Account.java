package atmCaseStudy;

public class Account {
   private int accountNumber; //account number
   private int pin; //PIN for authentication
   private double availableBalance; //funds available for withdrawal
   private double totalBalance; //funds available + pending deposits
   
   public Account(int theAccountNumber, int thePin, double theAvailableBalance, double theTotalBalance) {
	   accountNumber = theAccountNumber;
	   pin = thePin;
	   availableBalance = theAvailableBalance;
	   totalBalance = theTotalBalance;
   }
   
   public boolean validatePin(int userPIN) { //specified PIN matches the pin
	   if(pin == userPIN) {
		   return true;
	   }else {
		   return false;
	   }
   }
   
   public double getAvailableBalance() { //returns available balance
	   return availableBalance;
   }
   
   public double getTotalBalance() { //returns total balance
	   return totalBalance;
   }
   
   public void credit(double amount) {
	   totalBalance += amount;
   }
   
   public void debit(double amount) {
	   availableBalance -= amount;
	   totalBalance -= amount;
   }
   
   public int getAccountNumber() {
	   return accountNumber;
   }
}
