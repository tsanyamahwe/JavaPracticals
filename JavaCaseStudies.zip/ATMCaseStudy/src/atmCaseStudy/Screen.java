package atmCaseStudy;

public class Screen {
  public void displayMessage(String message) {//displays a message without a carriage return
	  System.out.print(message);
  }
  
  public void displayMessageLine(String message) {//displays a message with a carriage return
	  System.out.println(message);
  }
  
  public void displayAmountInRands(double amount) {//displays a Rand amount
	  System.out.printf("R%,.2f", amount);
  }
}
