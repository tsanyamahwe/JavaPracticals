package atmCaseStudy;
import java.util.*;

public class Keypad { //represents a keypad of the ATM
  private Scanner scanner;
  
  public Keypad() { //initializing a scanner
	  scanner = new Scanner(System.in);
  }
  
  public int getInput() { //return an integer value entered by user
	  return scanner.nextInt();
  }
}
