package atmCaseStudy;

public abstract class Transaction { //abstract superclass Transaction representing ATM transaction
    private int accountNumber;
    private Screen screen;
    private BankDatabase bankDatabase;
    
    public Transaction(int account, Screen atmScreen, BankDatabase database) {
    	accountNumber = account;
    	screen = atmScreen;
    	bankDatabase = database;
    }
    
    public int getAccountNumber() {
    	return accountNumber;
    }
    
    public Screen getScreen() {
    	return screen;
    }
    
    public BankDatabase getBankDatabase() {
    	return bankDatabase;
    }
    
    abstract void execute();
}
