package atmCaseStudy;

public class BankDatabase {
    private Account [] accounts;
    
    public BankDatabase() {
    	accounts = new Account[2];//just 2 accounts for testing
    	accounts[0] = new Account(12345, 54321, 1000.00, 1200.00);
    	accounts[1] = new Account(67890, 19876, 1787.45, 1895.13);
    }
    
    private Account getAccount(int accountNumber) { // retrieving Account object containing specified account number
    	for(Account currentAccount: accounts) {  //looping through accounts searching for matching account number
    		if(currentAccount.getAccountNumber() == accountNumber) { //if match found return current account
    			return currentAccount;
    		}
    	}
    	return null; //no match account number was found
    }
    
    public boolean authenticateUser(int accountNumber, int userPin) { //determining whether user specified account number matches the PIN
    	Account userAccount = getAccount(accountNumber); //retrieve the account
    	if(userAccount != null) {
    		return userAccount.validatePin(userPin);
    	}else {
    		return false;//account number not found
    	}
    }
    
    public double getAvailableBalance(int accountNumber) { //returns available balance in the specified account number
    	return getAccount(accountNumber).getAvailableBalance();
    }
    
    public double getTotalBalance(int accountNumber) { //returns total balance in the specified account number
    	return getAccount(accountNumber).getTotalBalance();
    }
    
    public void credit(int accountNumber, double amount) { //credit an amount to a specified account number
    	getAccount(accountNumber).credit(amount);
    }
    
    public void debit(int accountNumber, double amount) { //debit an amount from a specified account number
    	getAccount(accountNumber).debit(amount);
    }
}
