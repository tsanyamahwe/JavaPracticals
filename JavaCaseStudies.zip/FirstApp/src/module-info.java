/**
 * 
 */
/**
 * 
 */
module FirstApp {
	requires java.desktop;
}