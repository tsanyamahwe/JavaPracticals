package Java;

public class ArrayPractice {
  public static void arrayMethods()
  {
	  int [] array = {65, 67, 70, 72, 25, 56, 79, 94, 100, 87}; // declare an array
	  
	  System.out.println("The original array is:");
	  for (int number: array) 
	  {
		  System.out.printf(" %d", number);
	  }
	  
	  arrayModifier(array);
	  
	  System.out.println("\nAfter modification, the array looks like this:");
	  for (int value: array)
	  {
		  System.out.printf(" %d", value);
	  }
	  System.out.printf("\n\nModifying an element array [4] which is %d\n", array[4]);
	  arrayElementModifier(array[4]);
	  System.out.printf(" after modifying array [4] element %d", array[4]);
	  
  }
   public static void arrayModifier(int [] array2)
   {
	   for (int arr = 0; arr < array2.length; arr++)
	   {
		   array2[arr] *= 3;
	   }
   }
   
   public static void arrayElementModifier(int element)
   {
	   element *= 2;
	   System.out.printf("Will give a modified vlue of %d", element);
   }
   
   public static void main (String [] args)
   {
	   arrayMethods();
   }
}
