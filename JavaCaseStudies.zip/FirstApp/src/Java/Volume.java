package Java;
import java.util.*;

public class Volume {
  
	public static void intCylinderVolume() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Radius value:");
		int radius = scanner.nextInt();
		System.out.println("Enter Height value:");
		int height = scanner.nextInt();
		int volume = (int) (Math.PI * radius * radius * height);
		System.out.printf("The volume of the Integer Cylinder is %d\n", volume);
	}
	
	public static void doubleCylinderVolume() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Radius value:");
		double radius = scanner.nextDouble();
		System.out.println("Enter Height value:");
		double height = scanner.nextDouble();
		double volume =  Math.PI * radius * radius * height;
		System.out.printf("The volume of the double Cylinder is %.2f\n", volume);
	}
	
	public static void intSphereVolume() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Radius value:");
		int radius = scanner.nextInt();
		int volume = (int)((4/3) * Math.PI * radius * radius * radius );
		System.out.printf("The volume of the integer Sphere is %d\n", volume);
	}
	
	public static void doubleSphereVolume() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter Radius value:");
		double radius = scanner.nextDouble();
		double volume = ((4/3) * Math.PI * radius * radius * radius );
		System.out.printf("The volume of the double Sphere is %.2f\n", volume);
	}
	
	public static boolean isMultiple() {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter a the 1st number:");
		int num1 = scanner.nextInt();
		System.out.println("Enter a the 2nd number:");
		int num2 = scanner.nextInt();
		return (num1 % num2 == 0);
	}
	
	public static void main (String [] args) {	
		//intCylinderVolume();
		//doubleCylinderVolume();
		//intSphereVolume();
		//doubleSphereVolume();
		System.out.println(isMultiple());
	}
}
