package Java;
import java.util.*;

public class Craps {
   private static final Random randomNumber = new Random();
   
   private enum STATUS {CONTINUE, WON, LOST};
   
   private static final int SNAKE_EYES = 2;
   private static final int TREY = 3;
   private static final int SEVEN = 7;
   private static final int YO_LEVEN = 11;
   private static final int BOX_CARS = 12;
   
   public static final int rollDice() {
	   int dice1 = 1 + randomNumber.nextInt(6);
	   int dice2 = 1 + randomNumber.nextInt(6);
	   int sum = dice1 + dice2;
	   System.out.printf("The palyer roled %d + %d = %d\n", dice1, dice2, sum);
	   return sum;
   }
   
   public static void playCraps() {
	   int myPoint = 0;
	   STATUS gameStatus;
	   int sumOfDice = rollDice();
	   
	   switch(sumOfDice) {
	      case SEVEN:
	      case YO_LEVEN:
	    	  gameStatus = STATUS.WON;
	    	  break;
	      case SNAKE_EYES:
	      case TREY:
	      case BOX_CARS:
	    	  gameStatus = STATUS.LOST;
	    	  break;
	     default:
	    	 gameStatus = STATUS.CONTINUE;
	    	 myPoint = sumOfDice;
	    	 System.out.printf("Point is %d\n", myPoint);
	   }
	   while (gameStatus == STATUS.CONTINUE) {
		   sumOfDice = rollDice();
		   if (sumOfDice == myPoint) {
			   gameStatus = STATUS.WON;
		   }else if (sumOfDice == SEVEN) {
			   gameStatus = STATUS.LOST;
		   }    
	   }
	   if (gameStatus == STATUS.WON) {
		   System.out.println("The player has *WON!*");
	   }else
		   System.out.println("The player has *LOST!*");
   }
   
   public static void main (String [] args) {
	   playCraps();
   }
}
