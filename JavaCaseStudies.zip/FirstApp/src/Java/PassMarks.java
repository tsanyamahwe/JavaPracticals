package Java;
import java.util.*;

public class PassMarks {
	private int score;
	
	public PassMarks(int mark) {
		score = mark;
	}
	
	public PassMarks() {}
    
	public void setMark(int mark) {
		score = mark;
	}
	
	public int getMark () {
		return score;
	}
	
	public void displayMessage() {
		System.out.printf("", getMark());
	}
	
	public void determinePassAndFail() {
		Scanner input = new Scanner(System.in);
		int pass = 0, fail = 0, countStudent = 0, result;
		
		while (countStudent < 10) {
			System.out.print("Enter result (1 = pass 2 = fail):");
			result = input.nextInt();
			if (result == 1) {
				pass = pass + 1;
			}else {
				fail = fail + 1;
			}
			countStudent = countStudent + 1;
		}
		System.out.printf("Passes are %d and Fails are %d\n", pass, fail);
		if (pass >= 8) {
			System.out.println("The instructor to get a bonus!");
		}else {
			System.out.println("No bonus for the instructir!");
		}
	}
	
	public static void main (String [] args) {
		PassMarks passMark = new PassMarks();
		//passMark.displayMessage();
		passMark.determinePassAndFail();
	}
}
