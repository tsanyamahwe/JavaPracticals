package Java;
import java.util.Scanner;

public class BankBalance {
	private double balance;
	
	public BankBalance(double bankBalance) {
		//if (bankBalance > 0.0)
			balance = bankBalance;
	}
	
	public void Credit (double amount) {
		balance = balance + amount;
	}
	
	public double getBalance() {
		return balance;
	}
	
	public void displayMessage () {
		System.out.printf("Balance: $%.2f\n", getBalance());
	}
	
 public static void main(String [] args) {
	Scanner input = new Scanner(System.in);
	double depositAmount;
	BankBalance bankAccount1 = new BankBalance(50.00);
	BankBalance bankAccount2 = new BankBalance(-114.00);
	
	System.out.printf("Balance for account1 is: $%.2f\n", bankAccount1.getBalance());
	System.out.printf("Balance for account2 is: $%.2f\n", bankAccount2.getBalance());
	
	System.out.print("Enter the amount to be deposited for account1:");
	depositAmount = input.nextDouble();
	System.out.printf("Depositing $%.2f to account1.\n", depositAmount);
	bankAccount1.Credit(depositAmount);
	bankAccount1.displayMessage();
	System.out.println();
	System.out.print("Enter the amount to be deposited for uaccount2:");
	depositAmount = input.nextDouble();
	System.out.printf("Depositing $%.2f to account2.\n", depositAmount);
	bankAccount2.Credit(depositAmount);
	bankAccount2.displayMessage();
 }
}
