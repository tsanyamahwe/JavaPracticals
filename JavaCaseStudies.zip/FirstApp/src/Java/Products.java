package Java;
import java.util.*;

public class Products {
	private int productNumber, product1, product2, product3, product4;
	private double price1, price2, price3, price4;
    public Products() {}
    public void setProduct(int number) {
    	productNumber = number;
    }
    public int getProduct() {
    	return productNumber;
    }
    public void displayProducts() {
    	System.out.printf("The product is %d", getProduct());
    }
    public void sellProducts() {
    	Scanner input = new Scanner(System.in);
    	
    	System.out.println("Enter a product number:");
    	while(input.hasNext()) {
    		productNumber = input.nextInt();
    	    while(productNumber != 0) {
	    	    switch(productNumber) {
	    	      case 1:{
	    	    	  System.out.print("Enter quantity number:");
	    	    	  int quantity = input.nextInt();
	    	          price1 = quantity*2.98;
	    	          product1 += quantity;
	    	          }
	    	      break;
	    	      case 2:{
	    	    	  System.out.println("Enter quantity number:");
	    	    	  int quantity = input.nextInt();
	    	          price2 = quantity*4.50;
	    	          product2 += quantity;
	    	      }
	    	      break;
	    	      case 3:{
	    	    	  System.out.println("Enter quantity number:");
	    	    	  int quantity = input.nextInt();
	    	          price3 = quantity*9.98;
	    	          product3 += quantity;
	    	      }
	    	      break;
	    	      case 4:{
	    	    	  System.out.println("Enter quantity number:");
	    	    	  int quantity = input.nextInt();
	    	          price4 = quantity*4.50;
	    	          product4 += quantity;
	    	      }
	    	      System.out.println();
	    	    }
    	    }
    	}
    }
    /*public void totalCostAndProducts() {
    	double total = price1 + price2 + price3 + price4;
    	System.out.printf("Total cost for purchased products: %.2f\n", total);
    	System.out.printf("Product 1: %d, Product 2: %d, Product 3: %d, Product 4:%d\n", product1, product2, product3, product4);
    }*/
    public static void main (String [] argss) {
    	Products product = new Products();
    	product.sellProducts();
    	//product.totalCostAndProducts();
    }
}
