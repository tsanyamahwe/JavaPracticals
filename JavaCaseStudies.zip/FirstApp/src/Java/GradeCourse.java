package Java;
import java.util.Scanner;

public class GradeCourse {
	
	private String courseGrade;
	
	public GradeCourse(String gradeCourse) {
		courseGrade = gradeCourse;
	}
	
	public void setGradeCourse(String gradeCourse) {
		courseGrade = gradeCourse;
	}
	
	public String getGradeCourse() {
		return courseGrade;
	}
	
	public void displayMessage () {
		System.out.printf("Welcome to programming for beginners ~ %s\n", getGradeCourse());
	}
	
	public void determineClassAverage() {
		Scanner input = new Scanner(System.in);
		int grade, total = 0, gradeCounter = 0, average;
		
		System.out.println("Enter next grade OR -1 to exit:");
		grade = input.nextInt();
		while (grade != -1) {
			total = total + grade;
			gradeCounter ++;
			System.out.println("Enter next grade OR -1 to exit:");
			grade = input.nextInt();
		}
		if (gradeCounter !=0) {
			average = total/gradeCounter;
			System.out.printf("Total of %d grades is: %d\n", gradeCounter, total);
			System.out.printf("Course average is: %d", average);
		}
		else
			System.out.println("No grades were entered!");
	}
	public static void main(String[] args) {
		GradeCourse gradeCourse = new GradeCourse("CS01: Java Programming");
		gradeCourse.displayMessage();
		gradeCourse.determineClassAverage();
	}
}

