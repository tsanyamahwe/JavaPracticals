package Java;
import java.util.*;

public class Coin {
  private static final Random number = new Random();
  private enum TOSS {HEADS, TAILS};
  private static final int HEADS_COIN = 1;
  private static final int TAILS_COIN = 2;
  private static int frequency1 = 0, frequency2 = 0;
  
  public static int flipCoin() {
    int side = 1 + number.nextInt(2);
    return side;
  }
  
  public static void coinSides() {
	  TOSS tossCoin;
	  	  
	  for (int k = 1; k <= 20; k++) {
		  int coinside = flipCoin();
		  switch(coinside) {
		  case HEADS_COIN:
			  tossCoin = TOSS.HEADS;
			  ++frequency1;
			  break;
		  case TAILS_COIN:
			  tossCoin = TOSS.TAILS;
			  ++frequency2;
			  break;
		  }
	  }
	  System.out.printf("The HEADS were tossed %d times\n", frequency1);
	  System.out.printf("The TAILS were tossed %d times\n", frequency2);
  }
  public static void main (String [] args) {
	  coinSides();
  }
}
