package Java;
import java.util.Scanner;

public class GradeBook {
	private String courseName;
	private int total, gradeCounter, aCount, bCount, cCount, dCount, fCount;
	
	public GradeBook(String name) {
		courseName = name;
	}
	public void setCourseName(String name) {
		courseName = name;
	}
	public String getCourseName() {
		return courseName;
	}
	public void displayMessage () {
		System.out.printf("The name of the course is: %s\n", getCourseName());
	}
	public void inputGrades() {
		Scanner input = new Scanner(System.in);
		int mark;
		
		System.out.printf("%s\n%s\n%s\n", "Enter integer grades (0-100)", "Enter end of file indicator:", "<ctrl> z press enter");
		while(input.hasNext()) {
			mark = input.nextInt();
			total = total + mark;
			++gradeCounter;
			
			gradeClasses(mark);
			}
	}
	public void gradeClasses(int score) {
		switch (score/10) {
		   case 10:
		   case 9:
		   case 8:
			   ++aCount;
			   break;
			  
		   case 7:
		   case 6:
			   ++bCount;
			   break;
			   
		   case 5:
			   ++cCount;
			   break;
			   
		   case 4:
			   ++dCount;
			   break;
			   
		   default:
			   ++fCount;
			   break;
		}
	}
	public void reportGrades() {
		System.out.println("\nGrade Report:");
		if(gradeCounter != 0) {
			double average = (double)total/gradeCounter;
			System.out.printf("Total of the %d grades entered are %d\n", gradeCounter, total);
			System.out.printf("Class average is %.2f\n", average);
			System.out.printf("%s\n%s%d\n%s%d\n%s%d\n%s%d\n%s%d\n","Number of students who received each grade:",
					"A: ", aCount,
					"B: ", bCount,
					"C: ", cCount,
					"D: ", dCount,
					"F: ", fCount);
		}
		else
			System.out.println("No grades were entered!");
	}
	
 public static void main (String []args) {
	 GradeBook gradeBook = new GradeBook("CS 01 Introduction to Java");
	 gradeBook.displayMessage();
	 gradeBook.inputGrades();
	 gradeBook.reportGrades();
 }
}
