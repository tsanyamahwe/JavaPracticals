package Java;

public class Shadowing {
  private static int x = 1;
  
  public static void useLocalVariable() {
	  int x = 25;
	  
	  System.out.printf("Local x on entering function useLocalVariable is %d\n", x);
	  ++x;
	  System.out.printf("Local x on exiting function useLocalVariable is %d\n", x);
  }
  
  public static void useField() {
	  System.out.printf("Local value of x on entering function useField is %d\n", x);
	  x *= 10;
	  System.out.printf("Local value of x on exiting function useField is %d\n", x);
  }
  public static void main (String [] args) {
	  int x = 5;
	  System.out.printf("Local x in main is %d\n", x);
	  
	  useLocalVariable();
	  useField();
	  useLocalVariable();
	  useField();
	  
	  System.out .printf("\n Local x in main is %d", x);
  }
}
