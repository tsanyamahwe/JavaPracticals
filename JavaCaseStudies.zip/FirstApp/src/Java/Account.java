package Java;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class Account {
	private double bankBalance;
	
	public Account (double balance) {
		bankBalance = balance;
	}
	
	public void Credit (double balance) {
		bankBalance = bankBalance + balance;
	}
	
	public double getBalance() {
		return bankBalance;
	}
	
	public void displayMessage () {
		System.out.printf("Balance: $%.2f", getBalance());
	}
 public static void main(String [] args) {
	 Account account1 = new Account(50.00);
	 Account account2 = new Account(-70.00);
	 //String showBalance;
	 Scanner input = new Scanner(System.in);
	//
	 
	 String value = JOptionPane.showInputDialog("Deposit for account1");
	 double deposit = Double.parseDouble(value);
	 //deposit = input.nextDouble();
	 account1.Credit(deposit);
	  System.out.println();
	 String value1 = JOptionPane.showInputDialog("Deposit for account2");
	 deposit =Double.parseDouble(value1);
	 account2.Credit(deposit);
	 String showBalance1 = String.format("The balance for account1 is $%.2f\n", account1.getBalance());
	 String showBalance2 = String.format("The balance for account2 is $%.2f", account2.getBalance());
	 //String name = JOptionPane.showInputDialog("What is your name?");
	 //String message = String.format("Welcome to Introduction to Java Programming, %s!", name);
	 //JOptionPane.showMessageDialog(null, message);
	 JOptionPane.showMessageDialog(null, showBalance1 + showBalance2);
 }
}
