package Java;

public class Practice {
  public static void main (String [] args) {
	  double amount;
	  double principal = 1000.00;
	  double rate = 0.05;
	  
	  System.out.printf("%s%20s\n","Year","Amount on deposit");
	  
	  for (int year = 1; year <= 10; year++) {
		  amount = principal * Math.pow(1.0 + rate, year);
		  System.out.printf("%3d%15.2f\n", year, amount);
	  }
	  System.out.println();
	  
	  for(int i = 1; i <=5; i++) {
		  for (int j = 1; j <=2; j++) {
			  for (int k = 1; k <=5; k++) {
			       System.out.print("@");
			  }
		  }
		  System.out.println();
	  }
	  int count;
	  for (count = 1; count <= 10; count++) {
		  if (count == 5)
			  break;
		  System.out.printf("%d", count);
	  }
      System.out.printf("\nThe loop broke at count = %d\n", count);
      
      int counter;
      for (counter = 1; counter <=10; counter++) {
    	  if (counter == 5)
    		  continue;
    	  System.out.printf("%d", counter);
      }
      System.out.println("\nThe loop was used to skip 5");
  }
}
