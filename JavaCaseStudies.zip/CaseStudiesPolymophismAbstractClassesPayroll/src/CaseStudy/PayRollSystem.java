package CaseStudy;

public class PayRollSystem {
    public static void main (String [] args) {
    	SalariedEmployee salariedEmployee = new SalariedEmployee("Christian", "Bike", "111-111-111", 9874.63); 
    	HourlyEmployee hourlyEmployee = new HourlyEmployee("Donald", "Buke", "222-222-222", 40, 9546.74);
    	CommissionEmployee commissionEmployee = new CommissionEmployee ("Rennie", "Nechant", "333-333-333", 16765.45, .3);
    	BasePlusCommissionEmployee bpcommissionEmployee = new BasePlusCommissionEmployee("Reinard", "Fruncht", "444-444-444", 15765.76, .2, 6789.84);
    	
    	System.out.println("Employees processed individually:\n");
    	System.out.printf("%s\n%s: R%.2f\n\n", salariedEmployee, "Earned",salariedEmployee.earnings());
    	System.out.printf("%s\n%s: R%.2f\n\n", hourlyEmployee, "Earned", hourlyEmployee.earnings());
    	System.out.printf("%s\n%s: R%.2f\n\n", commissionEmployee, "Earned", commissionEmployee.earnings());
    	System.out.printf("%s\n%s: R%.2f\n\n", bpcommissionEmployee, "Earned", bpcommissionEmployee.earnings());
    	
    	Employee [] employee = new Employee [4];
    	employee [0] = salariedEmployee;
    	employee [1] = hourlyEmployee;
    	employee [2] = commissionEmployee;
    	employee [3] = bpcommissionEmployee;
    	
    	System.out.println("Employee processed polymorphically:\n");
    	for (Employee currentEmployee: employee) {
    		System.out.println(currentEmployee);
    		
    		if(currentEmployee instanceof BasePlusCommissionEmployee) {
    		   BasePlusCommissionEmployee employees = (BasePlusCommissionEmployee) currentEmployee;	
    		   employees.setBaseSalary(1.10 * employees.getBaseSalary());
    		   System.out.printf("New base salary with 10%% increment is: R%.2f\n", employees.getBaseSalary());
    		}
    		System.out.printf("Earned R%.2f\n\n", currentEmployee.earnings());
    	}
    	
    	for (int j = 0; j < employee.length; j++) {
    		System.out.printf("Employee %d is a %s\n", j, employee[j].getClass().getName());
    	}
    }
}
