package CaseStudy;

public class CommissionEmployee extends Employee{
     private double grossSales;
     private double commissionRate;
     
     public CommissionEmployee (String first, String last, String ssnumber, double sales, double rate) {
    	 super(first, last, ssnumber);
    	 setGrossSales(sales);
    	 setCommissionRate(rate);
     }
     
     public void setGrossSales(double sales) {
    	 if(sales >= 0.0) {
    		 grossSales = sales;
    	 }else {
    		 throw new IllegalArgumentException("Sales must be >= 0");
    	 }
     }
     
     public double getGrossSales() {
    	 return grossSales;
     }
     
     public void setCommissionRate(double rate) {
    	 if (0.0 <= rate && rate <= 1.0) {
    		 commissionRate = rate;
    	 }else {
    		 throw new IllegalArgumentException("Rate must be in the range 0.0 <= rate <= 1.0");
    	 }
     }
     
     public double getCommissionRate() {
    	 return commissionRate;
     }
     
     @Override
     public double earnings() {
    	 return getGrossSales() * getCommissionRate();
     }
     
     @Override
     public String toString() {
    	 return String.format("%s: %s\n%s: R%.2f\n%s: %.2f", "Commission Employee", super.toString(), "Gross Sales", getGrossSales(), "Commission Rate", getCommissionRate());
     }
}
