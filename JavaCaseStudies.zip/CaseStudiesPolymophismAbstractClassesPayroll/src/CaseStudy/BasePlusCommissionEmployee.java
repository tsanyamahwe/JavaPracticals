package CaseStudy;

public class BasePlusCommissionEmployee extends CommissionEmployee{
     private double baseSalary;
     
     public BasePlusCommissionEmployee(String first, String last, String ssnumber, double sales, double rate, double salary) {
    	 super(first, last, ssnumber, sales, rate);
    	 setBaseSalary(salary);
     }
     
     public void setBaseSalary(double salary) {
    	 if (salary >= 0) {
    		 baseSalary = salary;
    	 }else {
    		 throw new IllegalArgumentException("Salary should be >= 0");
    	 }
     }
     
     public double getBaseSalary() {
    	 return baseSalary;
     }
     
     @Override
     public double earnings() {
    	 return super.earnings() + getBaseSalary();
     }
     
     @Override
     public String toString() {
    	 return String.format("%s: %s\n%s: R%.2f", "Base-Plus-Commission Employee", super.toString(), "Base Salary", getBaseSalary());
     }
}
