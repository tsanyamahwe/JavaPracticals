package CaseStudy;

public class SalariedEmployee extends Employee{
      private double weeklySalary;
      
      public SalariedEmployee(String first, String last, String ssnumber, double salary) {
    	  super(first, last, ssnumber);
    	  setWeeklySalary(salary);
      }
      
      public void setWeeklySalary(double sal) {
    	  if(sal >= 0) {
    		  weeklySalary = sal;
    	  }else {
    		  throw new IllegalArgumentException("Weekly salary should be >= 0");
    	  }
      }
      
      public double getWeeklySalary() {
    	  return weeklySalary;
      }
      
      @Override
      public double earnings() {
    	  return weeklySalary;
      }
      
      @Override
      public String toString() {
    	  return String.format("Salaried Employee: %s\n%s: %.2f", super.toString(), "Weekly Salary", getWeeklySalary());
      }
}
