package CaseStudy;

public abstract class Employee {
      private String firstName;
      private String lastName;
      private String socialSecurityNumber;
      
      public Employee(String first, String last, String ssnumber) {
    	  firstName = first;
    	  lastName = last;
    	  socialSecurityNumber = ssnumber;
      }
      
      public void setFirstName(String name) {
    	  firstName = name;
      }
      
      public String getFirstName() {
    	  return firstName;
      }
      
      public void setLastName(String surname) {
    	  lastName = surname;
      }
      
      public String getLastName() {
    	  return lastName;
      }
      
      public void setSSNumber(String ssNumber) {
    	  socialSecurityNumber = ssNumber;
      }
      
      public String getSSNumber() {
    	  return socialSecurityNumber;
      }
      
      @Override
      public String toString() {
    	  return String.format("%s %s\nSocial Security Number: %s", getFirstName(), getLastName(), getSSNumber());
      }
      
      public abstract double earnings();
}
