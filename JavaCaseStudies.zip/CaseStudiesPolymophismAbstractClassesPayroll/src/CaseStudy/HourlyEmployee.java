package CaseStudy;

public class HourlyEmployee extends Employee{
      private int hours;
      private double wage;
      
      public HourlyEmployee(String first, String last, String ssnumber, int hrs, double wage) {
    	  super(first, last, ssnumber);
    	  setHours(hrs);
    	  setWage(wage);
      }
      
      public void setWage(double hrlyWage) {
    	  if(hrlyWage >= 0) {
    		  wage = hrlyWage;
    	  }else {
    		  throw new IllegalArgumentException("Hourly wage should be >= 0");
    	  }
      }
      
      public double getWage() {
    	  return wage;
      }
      
      public void setHours(int hrsWorked) {
    	  if((hrsWorked >= 0) && (hrsWorked <= 168)) {
    		  hours = hrsWorked;
    	  }else {
    		  throw new IllegalArgumentException("Hours worked should be in the range 0 <= hrs <= 168");
    	  }
      }
      
      public int getHours() {
    	  return hours;
      }
      
      @Override
      public double earnings() {
    	  if(getHours() <= 40) {
    		  return getWage() * getHours();
    	  }else {
    		  return 40 * getWage() + (getHours() - 40) * getWage() * 1.5;
    	  }
      }
      
      @Override
      public String toString() {
    	  return String.format("Hourly Employee: %s\n%s: %.2f\n%s %d", super.toString(), "Hourly Wage", getWage(), "Hours Worked", getHours());
      }
}
