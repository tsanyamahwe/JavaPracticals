package CaseStudy;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;
import java.lang.*;

public class CreditInquiry {
    private MenuOption accountTypes;
    private Scanner scanner;
    private static final MenuOption[] choices = {MenuOption.ZERO_BALANCE, MenuOption.CREDIT_BALANCE, MenuOption.DEBIT_BALANCE, MenuOption.END};
    
    private void readRecords() {
    	AccountRecord record = new AccountRecord();
    	
    	try {
    		scanner = new Scanner(new File("BankClients.txt"));
    		
    		while(scanner.hasNext()) {
    			record.setAccount(scanner.nextInt());
    			record.setFirstName(scanner.next());
    			record.setLastName(scanner.next());
    			record.setBalance(scanner.nextDouble());
    			
    			if(shouldDisplay(record.getBalance())) {
    				System.out.printf("%-10d%-12s%-12s%-10.2f\n", record.getAccount(), record.getFirstName(), record.getLastName(), record.getBalance());
    			}
    		}
    	}catch(NoSuchElementException noSuchElementException) {
    		System.err.println("File impropery formed");
    		scanner.close();
    		System.exit(1);
    	}catch(FileNotFoundException fileNotFoundException) {
    		System.err.println("File not found");
    		System.exit(1);
    	}catch(IllegalStateException illegalStateException) {
    		System.err.println("Error reading the file");
    		System.exit(1);
    	}finally {
    		if(scanner != null) {
    			scanner.close();
    		}
    	}
    }
    
    private boolean shouldDisplay(double balance) {
    	if((accountTypes == MenuOption.CREDIT_BALANCE) && (balance < 0)) {
    		return true;
    	}else if((accountTypes == MenuOption.DEBIT_BALANCE) && (balance > 0)) {
    		return true;
    	}else if((accountTypes == MenuOption.ZERO_BALANCE) && (balance == 0)) {
    		return true;
    	}
    	return false;
    }
    
    private MenuOption getRequest() {
    	Scanner scanner = new Scanner(System.in);
    	int request = 1;
    	
    	System.out.printf("\n%s\n%s\n%s\n%s\n%s\n",
    			"Enter Request",
    			"1: List accounts with ZERO balances",
    			"2: List accounts with CREDIT balances",
    			"3: List accounts with DEBIT balances",
    			"4: End of RUN");
    	
    	try {
    		do {
    			System.out.print("\n?");
    			request = scanner.nextInt();
    		}while((request < 1) || (request > 4));
    	}catch(NoSuchElementException noSuchElementException) {
    		System.err.println("Invalid input");
    		System.exit(1);
    	}
    	return choices[request - 1];
    }
    
    public void processRequests() {
    	accountTypes = getRequest();
    	if(accountTypes != MenuOption.END) {
    		switch(accountTypes) {
    		    case ZERO_BALANCE:
    		    	System.out.println("\nAccounts with ZERO balance:\n");
    		    	break;
    		    case CREDIT_BALANCE:
    		    	System.out.println("\nAccounts with CREDIT balance:\n");
    		    	break;
    		    case DEBIT_BALANCE:
    		    	System.out.println("\nAccount with DEBIT balance:\n");
    		}
    		readRecords();
    		accountTypes = getRequest();
    	}else {
    		System.exit(1);
    	}
    }
}
