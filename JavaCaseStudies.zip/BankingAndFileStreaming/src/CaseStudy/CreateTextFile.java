package CaseStudy;
import java.io.*;
import java.util.*;

public class CreateTextFile {
    private Formatter output;
    
    public void openFile() {
    	try {
    		output = new Formatter("BankClients.txt");
    	}catch(SecurityException securityException) {
    		System.err.println("You dont have write access to this file");
    		System.exit(1);
    	}catch(FileNotFoundException fileNotFoundException) {
    		System.err.println("Error file opening/creating file");
    		System.exit(1);
    	}
    }
    
    public void addRecords() {
    	AccountRecord record = new AccountRecord();
    	Scanner scanner = new Scanner(System.in);
    	
    	System.out.printf("%s\n%s\n%s\n\n",
    			"Provide an end-of-file delimeter to close the inputs:",
    			"1. On UNIX/Linux/Mac OS X type <ctrl> d then press Enter",
    			"2. On Windows type <ctrl> z then press Enter");
    	
    	System.out.printf("%s %s\n", "Provide \"Account (> 0)\", \"Name\", \"Surname\" and \"Balance\"", "?");
    	
    	while(scanner.hasNext()) {
    		try {
    			record.setAccount(scanner.nextInt());
    			record.setFirstName(scanner.next());
    			record.setLastName(scanner.next());
    			record.setBalance(scanner.nextDouble());
    			
    			if(record.getAccount() > 0) {
    				output.format("%-10d%-12s%-12s%-10.2f\n", record.getAccount(), record.getFirstName(), record.getLastName(), record.getBalance());
    			}else {
    				System.out.println("The account number should be > 0");
    			}
    		}catch(FormatterClosedException formatterClosedException) {
    			System.err.println("Error writing to the file");
    			scanner.close();
    			return;
    		}catch(NoSuchElementException noSuchElementException) {
    			System.err.println("Invalid input. Please try again");
    			scanner.nextLine();
    		}
    		System.out.printf("%s %s\n", "Provide \"Account (> 0)\", \"Name\", \"Surname\" and \"Balance\"", "?");
    	}
    	scanner.close();
    }
    
    public void closeFile() {
    	if(output != null) {
    		output.close();
    	}
    }
}
