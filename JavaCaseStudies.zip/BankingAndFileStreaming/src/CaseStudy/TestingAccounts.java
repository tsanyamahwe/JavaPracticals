package CaseStudy;
import java.util.*;

public class TestingAccounts {
    public static void main(String[]args) {
    	Scanner scanner = new Scanner(System.in);
    	System.out.printf("%s\n%s\n%s\n%s\n%s\n\n", "Enter the following options:","1. Creating a file","2. Reading from file","3. Credit Inquiries","4. Exit/Default");
	    while (scanner.hasNext()) {
	    	int option = scanner.nextInt();
	    	switch(option) {
	    	  case 1:
		    	CreateTextFile applicationCreate = new CreateTextFile();
		    	applicationCreate.openFile();
		    	applicationCreate.addRecords();
		    	applicationCreate.closeFile();
		    	break;
	    	  case 2:
		    	ReadTextFile applicationRead = new ReadTextFile();
		    	applicationRead.openFile();
		    	applicationRead.readRecords();
		    	applicationRead.closeFile();
		    	break;
	    	  case 3:
		    	CreditInquiry applicationCredit = new CreditInquiry();
		    	applicationCredit.processRequests();
		    	break;
		      default:
		    	  System.exit(1);
	    	}
	    	System.out.printf("\n\n%s\n%s\n%s\n%s\n%s\n\n", "Enter the following options:","1. Creating a file","2. Reading from file","3. Credit Inquiries","4. Exit/Default");
	    }
    }
}
